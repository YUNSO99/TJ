import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from lightgbm import LGBMRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import mean_squared_error
import joblib # 모델 저장을 위해 추가
import os # 디렉토리 생성을 위해 추가

def train_pace_prediction_model(data_path="model_ready_data.csv", model_save_path="models/pace_model.pkl"):
    """
    전처리된 데이터를 로드하여 구간별 페이스 예측 모델을 학습시키고 저장합니다.
    """
    try:
        print(f"'{data_path}'에서 모델 학습용 데이터 로딩 중...")
        df = pd.read_csv(data_path)
        print("데이터 로딩 완료.")
    except FileNotFoundError:
        print(f"FATAL Error: 학습 데이터를 찾을 수 없습니다. '{data_path}' 경로를 확인해주세요.")
        return
    except Exception as e:
        print(f"FATAL Error: 데이터 로딩 중 오류 발생 - {e}")
        return

    # --- 1. 특성(X)과 목표 변수(Y) 정의 ---
    # 예측할 목표 페이스 컬럼들 (스크립트 결과물에 따라 정확한 이름 사용)
    target_pace_columns = [
        'target_pace_0_5km', 'target_pace_5_10km', 'target_pace_10_15km', 
        'target_pace_15_Half', 'target_pace_Half_25km', 'target_pace_25_30km', 
        'target_pace_30_35km', 'target_pace_35_40km', 'target_pace_40_finish'
    ]
    
    # 실제 데이터프레임에 있는 목표 페이스 컬럼만 선택
    Y = df[[col for col in target_pace_columns if col in df.columns]].copy()
    if Y.empty:
        print("FATAL Error: 목표 변수 컬럼을 찾을 수 없습니다. 컬럼명을 확인해주세요.")
        return

    # 입력 특성 컬럼들 (목표 변수와 ID성 컬럼 제외)
    # Dataset_*, Sub_* 등 원-핫 인코딩된 컬럼들은 자동으로 포함됨
    feature_columns = [
        'age_numeric', 'M/F', 'Year', 
        'temperature_race', 'humidity_race',
        'user_weekly_km', 'user_target_time_sec'
    ]
    # 원-핫 인코딩된 Dataset 및 Sub 컬럼명 추가
    dataset_ohe_cols = [col for col in df.columns if col.startswith('Dataset_')]
    sub_ohe_cols = [col for col in df.columns if col.startswith('Sub_')]
    
    feature_columns.extend(dataset_ohe_cols)
    feature_columns.extend(sub_ohe_cols)
    
    # 실제 데이터프레임에 있는 특성 컬럼만 선택
    X = df[[col for col in feature_columns if col in df.columns]].copy()
    if X.empty:
        print("FATAL Error: 입력 특성 컬럼을 찾을 수 없습니다. 컬럼명을 확인해주세요.")
        return

    print(f"\n입력 특성 (X) 컬럼 ( {len(X.columns)}개 ): {X.columns.tolist()}")
    print(f"목표 변수 (Y) 컬럼 ( {len(Y.columns)}개 ): {Y.columns.tolist()}")

    # --- 2. 학습/테스트 데이터 분할 ---
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
    print(f"\n데이터 분할 완료: 학습용 {X_train.shape[0]}개, 테스트용 {X_test.shape[0]}개")

    # --- 3. 플레이스홀더 특성 결측치 처리 (학습 데이터에만 적용) ---
    # user_weekly_km, user_target_time_sec는 예측 시 사용자 입력을 받지만,
    # 학습 데이터에서는 NaN일 수 있으므로 적절한 값으로 대체 (예: 0, 평균, 중앙값)
    # 여기서는 간단히 0으로 대체 (또는 평균/중앙값 사용 가능)
    cols_to_impute_train = {}
    if 'user_weekly_km' in X_train.columns:
        median_weekly_km = X_train['user_weekly_km'].median() if not X_train['user_weekly_km'].isnull().all() else 50 # 전체가 NaN이면 기본값
        X_train['user_weekly_km'].fillna(median_weekly_km, inplace=True)
        X_test['user_weekly_km'].fillna(median_weekly_km, inplace=True) # 테스트셋에도 동일하게 적용
        cols_to_impute_train['user_weekly_km'] = median_weekly_km
        print(f"'user_weekly_km' 결측치 처리: 중앙값 {median_weekly_km} (또는 기본값) 사용.")

    if 'user_target_time_sec' in X_train.columns:
        median_target_time = X_train['user_target_time_sec'].median() if not X_train['user_target_time_sec'].isnull().all() else 14400 # 4시간 (전체가 NaN이면 기본값)
        X_train['user_target_time_sec'].fillna(median_target_time, inplace=True)
        X_test['user_target_time_sec'].fillna(median_target_time, inplace=True) # 테스트셋에도 동일하게 적용
        cols_to_impute_train['user_target_time_sec'] = median_target_time
        print(f"'user_target_time_sec' 결측치 처리: 중앙값 {median_target_time} (또는 기본값) 사용.")
    
    # 목표 변수(y_train, y_test)의 결측치 확인 및 처리
    # MultiOutputRegressor는 Y에 NaN이 있으면 오류 발생 가능성
    # 이전 단계에서 주요 목표 변수 NaN 행을 제거했지만, 다시 한번 확인
    y_train.dropna(inplace=True)
    X_train = X_train.loc[y_train.index] # y_train에서 NaN 제거 후 X_train도 인덱스 맞춰주기

    y_test.dropna(inplace=True)
    X_test = X_test.loc[y_test.index]
    
    if y_train.empty or y_test.empty:
        print("FATAL Error: 목표 변수(Y)에 유효한 데이터가 없습니다 (NaN 제거 후).")
        return

    print("학습/테스트 데이터 결측치 처리 완료.")

    # --- 4. LightGBM 모델 학습 (다중 출력) ---
    print("\nLightGBM 모델 학습 시작...")
    # 기본 LGBMRegressor 모델
    lgbm = LGBMRegressor(random_state=42)
    # 다중 출력을 위한 MultiOutputRegressor 래퍼 사용
    multioutput_lgbm = MultiOutputRegressor(lgbm)

    multioutput_lgbm.fit(X_train, y_train)
    print("모델 학습 완료.")

    # --- 5. 모델 성능 평가 ---
    y_pred_train = multioutput_lgbm.predict(X_train)
    y_pred_test = multioutput_lgbm.predict(X_test)

    print("\n모델 성능 평가 (RMSE - 초/km 단위):")
    train_rmse_sum = 0
    test_rmse_sum = 0
    for i, col_name in enumerate(Y.columns):
        train_rmse = np.sqrt(mean_squared_error(y_train.iloc[:, i], y_pred_train[:, i]))
        test_rmse = np.sqrt(mean_squared_error(y_test.iloc[:, i], y_pred_test[:, i]))
        print(f"  - {col_name}: Train RMSE = {train_rmse:.2f} sec/km, Test RMSE = {test_rmse:.2f} sec/km")
        train_rmse_sum += train_rmse
        test_rmse_sum += test_rmse
    
    avg_train_rmse = train_rmse_sum / len(Y.columns)
    avg_test_rmse = test_rmse_sum / len(Y.columns)
    print(f"  ---------------------------------------------------")
    print(f"  평균 RMSE: Train = {avg_train_rmse:.2f} sec/km, Test = {avg_test_rmse:.2f} sec/km")

    # --- 6. 학습된 모델 저장 ---
    try:
        model_dir = os.path.dirname(model_save_path)
        if model_dir and not os.path.exists(model_dir): # model_dir이 비어있지 않고 존재하지 않을 경우
            os.makedirs(model_dir)
            print(f"모델 저장 디렉토리 '{model_dir}' 생성 완료.")
        
        joblib.dump(multioutput_lgbm, model_save_path)
        print(f"\n학습된 페이스 예측 모델이 '{model_save_path}'에 저장되었습니다.")
        
        # 결측치 처리에 사용된 값들도 함께 저장하면 예측 시 유용 (선택 사항)
        imputation_values_path = os.path.join(model_dir, "imputation_values.json")
        import json
        with open(imputation_values_path, 'w') as f:
            json.dump(cols_to_impute_train, f)
        print(f"결측치 처리에 사용된 값이 '{imputation_values_path}'에 저장되었습니다.")

    except Exception as e:
        print(f"Error: 모델 저장 중 오류 발생 - {e}")

if __name__ == '__main__':
    # ★★★ 사용자 설정: 입력 파일 경로와 모델 저장 경로를 지정해주세요. ★★★
    MODEL_READY_DATA_PATH = "./model_ready_data.csv"  # 이전 단계에서 생성된 파일
    PACE_MODEL_SAVE_PATH = "./models/pace_prediction_model.pkl" # 학습된 모델 저장 경로
    # ==============================================================================

    train_pace_prediction_model(data_path=MODEL_READY_DATA_PATH, 
                                model_save_path=PACE_MODEL_SAVE_PATH)

    print("\n--- 구간별 페이스 예측 모델 학습 완료 ---")
    print("다음 단계는 목표 달성 확률 예측 모델(예: 로지스틱 회귀)을 학습시키는 것입니다.")