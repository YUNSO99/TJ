import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler
import joblib
import os
import json

def train_achievement_probability_model(
    data_path="augmented_prob_model_data.csv", # 증강된 데이터 파일
    model_save_path="models/achievement_probability_model_v2.pkl",
    imputation_values_path="models/imputation_values.json"
    ):
    """
    증강된 데이터를 로드하여 목표 달성 확률 예측 모델(로지스틱 회귀)을 학습하고 저장합니다.
    """
    try:
        print(f"'{data_path}'에서 증강된 학습 데이터 로딩 중...")
        df = pd.read_csv(data_path)
        print("데이터 로딩 완료.")
    except FileNotFoundError:
        print(f"FATAL Error: 학습 데이터를 찾을 수 없습니다. '{data_path}' 경로를 확인해주세요.")
        return
    except Exception as e:
        print(f"FATAL Error: 데이터 로딩 중 오류 발생 - {e}")
        return

    # --- 1. 목표 변수 (target_achieved) 및 특성(X) 정의 ---
    if 'target_achieved' not in df.columns or df['target_achieved'].isnull().all():
        print("FATAL Error: 유효한 'target_achieved' 목표 변수가 데이터에 없습니다.")
        return
    Y_prob = df['target_achieved']

    # ★★★ 사용자가 제공한 최종 특성 목록 (13개) ★★★
    # 이 목록은 prediction_pipeline.py의 EXPECTED_PROB_MODEL_FEATURES와 정확히 일치해야 합니다.
    feature_columns_final = [
        'age_numeric', 'M/F', 'Year', 
        'temperature_race', 'humidity_race',
        'user_weekly_km', 'user_target_time_sec',
        'Dataset_B', 'Dataset_C', 'Dataset_M', 
        'target_sub_category_4', 'target_sub_category_5', 'target_sub_category_6'
    ]
    
    # 데이터프레임에 실제 존재하는 특성들만 선택
    X_prob = df[[col for col in feature_columns_final if col in df.columns]].copy()

    if X_prob.empty or X_prob.shape[1] == 0:
        print("FATAL Error: 입력 특성 컬럼을 찾을 수 없거나, 유효한 특성이 없습니다.")
        print(f"요청된 특성: {feature_columns_final}")
        print(f"데이터에 있는 컬럼: {df.columns.tolist()}")
        return
    
    # 실제 선택된 특성 목록 확인 (요청된 13개와 일치하는지)
    if len(X_prob.columns) != len(feature_columns_final):
        print("Warning: 요청된 모든 특성이 데이터에 존재하지 않을 수 있습니다.")
        print(f"  요청된 특성 수: {len(feature_columns_final)}")
        print(f"  실제 선택된 특성 수: {len(X_prob.columns)}")

    print(f"\n입력 특성 (X_prob) 컬럼 ( {len(X_prob.columns)}개 ): {X_prob.columns.tolist()}")
    print(f"목표 변수 (Y_prob) 값 분포:\n{Y_prob.value_counts(normalize=True)}")

    # --- 2. 학습/테스트 데이터 분할 ---
    X_train, X_test, y_train, y_test = train_test_split(
        X_prob, Y_prob,
        test_size=0.2,
        random_state=42,
        stratify=Y_prob if Y_prob.nunique() > 1 else None
    )
    print(f"\n데이터 분할 완료: 학습용 {X_train.shape[0]}개, 테스트용 {X_test.shape[0]}개")

    # --- 3. 'user_weekly_km' 결측치 처리 (필요시) 및 스케일링 ---
    imputation_map_loaded = {}
    if os.path.exists(imputation_values_path):
        with open(imputation_values_path, 'r') as f:
            imputation_map_loaded = json.load(f)
        print(f"'{imputation_values_path}'에서 결측치 대체값 로드 완료.")
    
    if 'user_weekly_km' in X_train.columns:
        fill_value_wk = imputation_map_loaded.get('user_weekly_km')
        if fill_value_wk is None: 
            fill_value_wk = X_train['user_weekly_km'].median() if not X_train['user_weekly_km'].isnull().all() else 50.0
            imputation_map_loaded['user_weekly_km'] = fill_value_wk
            print(f"Warning: 'user_weekly_km' 대체값이 파일에 없어 새로 중앙값({fill_value_wk}) 계산.")

        X_train['user_weekly_km'].fillna(fill_value_wk, inplace=True)
        X_test['user_weekly_km'].fillna(fill_value_wk, inplace=True) # 테스트셋에도 동일하게 적용
        print(f"'user_weekly_km' 결측치 처리: 값 {fill_value_wk} 사용.")
    
    # 다른 숫자형 특성에 NaN이 있다면, 간단히 중앙값으로 채우기 (더 정교한 처리 가능)
    for col in X_train.select_dtypes(include=np.number).columns:
        if X_train[col].isnull().any():
            median_val = X_train[col].median()
            X_train[col].fillna(median_val, inplace=True)
            X_test[col].fillna(median_val, inplace=True) # 테스트셋에도 동일하게 적용
            print(f"'{col}' 컬럼의 NaN 값을 중앙값({median_val})으로 대체했습니다.")


    # 특성 스케일링
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    print("특성 스케일링 완료 (StandardScaler).")
    print(X_train.columns.tolist())

    # --- 4. 로지스틱 회귀 모델 재학습 ---
    print("\n로지스틱 회귀 모델 재학습 시작...")
    log_reg = LogisticRegression(
        random_state=42,
        solver='liblinear', 
        class_weight='balanced' if Y_prob.nunique() > 1 and Y_prob.value_counts(normalize=True).min() < 0.2 else None,
        max_iter=1000 # 수렴 문제 방지 위해 증가
    )
    log_reg.fit(X_train_scaled, y_train)
    print("모델 재학습 완료.")

    # --- 5. 모델 성능 평가 ---
    y_pred_train = log_reg.predict(X_train_scaled)
    y_pred_proba_train = log_reg.predict_proba(X_train_scaled)[:, 1]
    y_pred_test = log_reg.predict(X_test_scaled)
    y_pred_proba_test = log_reg.predict_proba(X_test_scaled)[:, 1]

    print("\n재학습된 모델 성능 평가 (목표 달성 확률):")
    print(f"  Train Accuracy: {accuracy_score(y_train, y_pred_train):.4f}")
    print(f"  Test Accuracy: {accuracy_score(y_test, y_pred_test):.4f}")
    if Y_prob.nunique() > 1 :
        print(f"  Train AUC: {roc_auc_score(y_train, y_pred_proba_train):.4f}")
        print(f"  Test AUC: {roc_auc_score(y_test, y_pred_proba_test):.4f}")
    
    print("\n  Test Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred_test))
    print("\n  Test Classification Report:")
    print(classification_report(y_test, y_pred_test, zero_division=0))

    # --- 6. 학습된 모델 및 스케일러 저장 ---
    try:
        model_dir = os.path.dirname(model_save_path)
        if model_dir and not os.path.exists(model_dir): # model_dir이 빈 문자열이 아니고, 존재하지 않을 때만 생성
            os.makedirs(model_dir)
        
        joblib.dump({'model': log_reg, 'scaler': scaler, 'features': X_train.columns.tolist()}, model_save_path) # ★★★ 학습된 특성명 리스트도 함께 저장 ★★★
        print(f"\n재학습된 확률 예측 모델, 스케일러, 특성명이 '{model_save_path}'에 저장되었습니다.")
        
        # imputation_map_loaded가 업데이트 되었다면 다시 저장 (선택적)
        # if 'user_weekly_km' in imputation_map_loaded and imputation_map_loaded.get('user_weekly_km_newly_calculated', False):
        #    del imputation_map_loaded['user_weekly_km_newly_calculated'] # 임시 플래그 제거
        #    with open(imputation_values_path, 'w') as f:
        #       json.dump(imputation_map_loaded, f)
        #    print(f"결측치 처리에 사용된 값이 '{imputation_values_path}'에 업데이트/저장되었습니다.")

    except Exception as e:
        print(f"Error: 모델 또는 스케일러 저장 중 오류 발생 - {e}")

if __name__ == '__main__':
    # ★★★ 사용자 설정 ★★★
    AUGMENTED_DATA_PATH = "./augmented_prob_model_data.csv" 
    NEW_PROB_MODEL_SAVE_PATH = "./models/achievement_probability_model_v2.pkl" 
    IMPUTATION_VALUES_PATH_LOAD = "./models/imputation_values.json" 
    
    train_achievement_probability_model(
        data_path=AUGMENTED_DATA_PATH, 
        model_save_path=NEW_PROB_MODEL_SAVE_PATH,
        imputation_values_path=IMPUTATION_VALUES_PATH_LOAD
    )

    print("\n--- 목표 달성 확률 예측 모델 재학습 완료 ---")
    print(f"이제 '{NEW_PROB_MODEL_SAVE_PATH}' 모델을 prediction_pipeline.py에서 사용하도록 경로를 수정하고,")
    print("prediction_pipeline.py의 EXPECTED_PROB_MODEL_FEATURES 리스트를 위 학습에 사용된 특성들과 정확히 일치시키세요.")