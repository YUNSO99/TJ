import streamlit as st
import pandas as pd # prediction_pipeline 내부에서 pandas를 사용할 수 있으므로, 명시적으로 임포트 권장
import numpy as np # prediction_pipeline 내부에서 numpy를 사용할 수 있으므로, 명시적으로 임포트 권장
from datetime import datetime

# prediction_pipeline.py에서 예측 함수 및 필요한 상수 가져오기
# (prediction_pipeline.py가 app.py와 같은 디렉토리에 있다고 가정)
try:
    # TARGET_PACE_COLUMN_NAMES는 결과 표 및 차트 생성에 필요합니다.
    from prediction_pipeline import predict_marathon_strategy, TARGET_PACE_COLUMN_NAMES
except ImportError:
    st.error("""
    오류: 'prediction_pipeline.py' 파일을 찾을 수 없거나, 
    해당 파일에서 'predict_marathon_strategy' 함수 또는 'TARGET_PACE_COLUMN_NAMES' 상수를 가져올 수 없습니다. 
    파일 위치와 내용을 확인해주세요.
    `prediction_pipeline.py`에는 다음이 포함되어야 합니다:
    1. `predict_marathon_strategy` 함수 정의
    2. `TARGET_PACE_COLUMN_NAMES` 리스트 정의 (페이스 모델 출력 순서대로)
    3. 모델 로딩 및 필요한 상수(EXPECTED_MODEL_FEATURES 등) 정의
    """)
    st.stop()
except Exception as e:
    st.error(f"prediction_pipeline 임포트 중 예기치 않은 오류 발생: {e}")
    st.stop()


# --- 페이지 기본 설정 ---
st.set_page_config(
    page_title="마라톤 페이스 전략 AI",
    page_icon="🏃‍♂️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- 대시보드 제목 및 소개 ---
st.title("AI 기반 개인 맞춤형 마라톤 페이스 전략 🏃‍♀️💨")
st.markdown("""
당신의 목표와 컨디션, 예상되는 레이스 환경을 입력하고,
AI가 추천하는 최적의 구간별 페이스와 목표 달성 가능성을 확인해보세요!
이 전략은 수만 건의 실제 마라톤 기록과 날씨 데이터를 학습한 모델을 기반으로 제공됩니다.
""")
st.markdown("---")

# --- 사용자 정보 입력 섹션 (사이드바) ---
with st.sidebar:
    st.header("🏁 레이스 정보 입력")

    sex_options = ["남성", "여성"]
    sex_str_input = st.selectbox("성별 (Sex)", sex_options, help="성별을 선택해주세요.")

    age_input = st.number_input("나이 (Age)", min_value=18, max_value=99, value=30, step=1, help="만 나이를 입력해주세요.")
    
    # weekly_km_input, race_year_input, aspirational_sub_category_input는 사용자 입력에서 제외됨

    st.subheader("🎯 목표 완주 시간")
    target_hours = st.number_input("시간 (Hours)", min_value=2, max_value=7, value=4, step=1, key="th", help="목표 완주 시간의 '시'를 입력하세요.")
    target_minutes = st.number_input("분 (Minutes)", min_value=0, max_value=59, value=0, step=1, key="tm", help="목표 완주 시간의 '분'을 입력하세요.")
    target_seconds = st.number_input("초 (Seconds)", min_value=0, max_value=59, value=0, step=1, key="ts", help="목표 완주 시간의 '초'를 입력하세요.")
    
    target_time_total_seconds_input = (target_hours * 3600) + (target_minutes * 60) + target_seconds

    st.subheader("☀️ 예상 날씨")
    temperature_input = st.slider("평균 기온 (°C)", min_value=-10.0, max_value=40.0, value=15.0, step=0.5, format="%.1f", help="레이스 시간 동안 예상되는 평균 기온을 입력하세요.")
    humidity_input = st.slider("평균 습도 (%)", min_value=0, max_value=100, value=60, step=1, help="레이스 시간 동안 예상되는 평균 상대 습도를 입력하세요.")

    st.subheader("코스 유형 (선택 사항)")
    # prediction_pipeline.py에서 ref_dataset_code의 기본값이 'B'로 설정되어 있으므로,
    # 사용자가 선택하지 않아도 기본값으로 작동 가능.
    # 또는 '일반' 옵션을 추가하여 사용자가 명시적으로 선택하도록 유도.
    dataset_options_map = {
        "보스턴 마라톤 코스 유형": 'B',
        "모스크바 마라톤 코스 유형": 'M',
        "시카고 마라톤 코스 유형": 'C',
        "일반/알수없음": 'UNKNOWN' # prediction_pipeline.py에서 이 'UNKNOWN'을 처리하는 로직 필요 (예: 모든 Dataset_X OHE를 0으로)
    }
    ref_dataset_str = st.selectbox(
        "참고 코스 유형", 
        options=list(dataset_options_map.keys()), 
        index=0, # 기본값 보스턴
        help="예상하는 레이스 코스와 가장 유사한 유형을 선택하거나, 잘 모르면 '일반/알수없음'을 선택하세요."
    )
    ref_dataset_code_input = dataset_options_map[ref_dataset_str]

    submit_button = st.button("나의 페이스 전략 보기 ✨")

# --- 결과 표시 섹션 (메인 화면) ---
if submit_button:
    if 'TARGET_PACE_COLUMN_NAMES' not in globals() or not TARGET_PACE_COLUMN_NAMES:
        st.error("오류: `TARGET_PACE_COLUMN_NAMES` 상수가 `prediction_pipeline.py`에 올바르게 정의되지 않았거나 로드되지 않았습니다.")
    else:
        with st.spinner("AI가 최적의 페이스 전략을 계산 중입니다... 잠시만 기다려주세요 🤔"):
            # `predict_marathon_strategy` 함수 호출 시 제외된 인자들 제거
            predicted_paces, probability, temp_penalty = predict_marathon_strategy(
                age=age_input,
                sex_str=sex_str_input,
                target_time_total_seconds=target_time_total_seconds_input,
                temperature=temperature_input,
                humidity=humidity_input,
                ref_dataset_code=ref_dataset_code_input
                # weekly_km, race_year, aspirational_sub_category는 함수 내부에서 기본값/계산값 사용
            )

        if predicted_paces is not None and probability is not None:
            st.subheader("📈 당신을 위한 맞춤형 마라톤 전략 결과")

            # 1. 핵심 요약 정보
            col1, col2 = st.columns([1,2]) # 확률 표시 컬럼을 약간 좁게
            with col1:
                st.metric(label="🎯 목표 달성 예상 확률", value=f"{probability*100:.2f}%")
                st.progress(int(probability*100))
            
            # 2. 열 스트레스 및 기온 페널티 (col2에 표시)
            with col2:
                heat_stress_level = "낮음"
                advice = "수분 섭취에 유의하며 레이스를 즐기세요!"
                # 열 스트레스 조건 단순화 (예시)
                if temperature_input >= 28 or (temperature_input >= 24 and humidity_input >= 75):
                    heat_stress_level = "매우 높음 🥵"
                    advice = "탈수 및 열 관련 질환 위험이 매우 높습니다! 레이스 참여를 재고하거나 목표를 대폭 수정하고, 충분한 수분 섭취와 휴식이 필수입니다."
                    st.error(f"열 스트레스: {heat_stress_level}\n\n{advice}")
                elif temperature_input >= 24 or (temperature_input >= 20 and humidity_input >= 80):
                    heat_stress_level = "높음 🌡️"
                    advice = "상당한 열 스트레스가 예상됩니다. 수분 섭취에 각별히 신경 쓰고, 페이스를 평소보다 보수적으로 운영하세요."
                    st.warning(f"열 스트레스: {heat_stress_level}\n\n{advice}")
                elif temperature_input >= 20 or (temperature_input >= 18 and humidity_input >= 85):
                    heat_stress_level = "주의 😥"
                    advice = "다소 더위를 느낄 수 있습니다. 수분 섭취 계획을 잘 세우고, 몸 상태를 주시하세요."
                    st.info(f"열 스트레스: {heat_stress_level}\n\n{advice}")
                else:
                    st.success(f"쾌적한 레이스가 예상됩니다! (열 스트레스 {heat_stress_level})")
                
                st.caption(f"예상 기온 페널티: 약 +{temp_penalty:.1f} 초/km (12°C 초과 시)")
            
            st.markdown("---")

            # 3. 구간별 추천 페이스 상세
            st.markdown("####  구간별 추천 페이스 전략")
            
            pace_display_data = []
            # ★★★ 아래 segment_names와 segment_lengths_km는 
            #     prediction_pipeline.py의 TARGET_PACE_COLUMN_NAMES와 정확히 일치해야 합니다. ★★★
            segment_names = [ 
                "0km - 5km", "5km - 10km", "10km - 15km", "15km - 하프지점", "하프지점 - 25km", 
                "25km - 30km", "30km - 35km", "35km - 40km", "40km - 완주지점"
            ]
            segment_lengths_km = [ 
                5.0, 5.0, 5.0, 21.0975 - 15.0, 25.0 - 21.0975,
                5.0, 5.0, 5.0, 42.195 - 40.0
            ]

            if len(segment_names) != len(TARGET_PACE_COLUMN_NAMES) or \
               len(segment_lengths_km) != len(TARGET_PACE_COLUMN_NAMES) or \
               len(predicted_paces) != len(TARGET_PACE_COLUMN_NAMES):
                st.error("""
                    오류: 코드 내 `TARGET_PACE_COLUMN_NAMES`, `segment_names`, `segment_lengths_km`의
                    길이 또는 예측된 페이스의 개수가 일치하지 않습니다. 
                    `prediction_pipeline.py`와 `app.py`의 해당 상수 정의를 점검해주세요.
                """)
            else:
                cumulative_time_sec = 0
                chart_pace_data = [] # 차트용 데이터

                for i, key in enumerate(TARGET_PACE_COLUMN_NAMES):
                    pace_sec_km = predicted_paces.get(key, 0) 
                    minutes = int(pace_sec_km // 60)
                    seconds = int(pace_sec_km % 60)
                    
                    current_segment_length = segment_lengths_km[i]
                    segment_time_sec = pace_sec_km * current_segment_length
                    cumulative_time_sec += segment_time_sec
                    
                    seg_h = int(segment_time_sec // 3600)
                    seg_m = int((segment_time_sec % 3600) // 60)
                    seg_s = int(segment_time_sec % 60)
                    
                    cum_h = int(cumulative_time_sec // 3600)
                    cum_m = int((cumulative_time_sec % 3600) // 60)
                    cum_s = int(cumulative_time_sec % 60)

                    pace_display_data.append({
                        "구간": segment_names[i],
                        "추천 페이스 (분:초/km)": f"{minutes:02d}:{seconds:02d}",
                        "구간 예상 시간": f"{seg_h:02d}시 {seg_m:02d}분 {seg_s:02d}초" if seg_h > 0 else f"{seg_m:02d}분 {seg_s:02d}초",
                        "누적 예상 시간": f"{cum_h:02d}시 {cum_m:02d}분 {cum_s:02d}초"
                    })
                    chart_pace_data.append(pace_sec_km) # 차트용 데이터 (초/km)
                
                pace_df = pd.DataFrame(pace_display_data)
                st.table(pace_df)

                # 추천 페이스 기반 총 예상 완주 시간 (표의 마지막 누적 시간과 동일)
                # col2에 이미 st.metric으로 표시되도록 로직 변경 가능 (만약 위에서 주석처리했다면)
                # st.markdown(f"#### ⏱️ 추천 페이스 기반 총 예상 완주 시간: **{cum_h:02d}시간 {cum_m:02d}분 {cum_s:02d}초**")


                # 4. 페이스 변화 시각화
                st.markdown("#### 페이스 변화 그래프 (초/km)")
                chart_df = pd.DataFrame({
                    '구간': segment_names, # segment_names 사용
                    '페이스 (초/km)': chart_pace_data
                })
                st.line_chart(chart_df.set_index('구간'))

            st.markdown("---")
            st.info("""
            **💡 참고 및 주의사항:**
            * 이 추천은 입력된 정보와 과거 데이터를 기반으로 한 통계적 예측입니다.
            * 실제 레이스 중 개인의 컨디션, 예상치 못한 날씨 변화, 코스 상세 특성(고도 등)에 따라 페이스 조절이 필요할 수 있습니다.
            * 항상 자신의 몸에 귀 기울이며 안전하고 즐거운 레이스를 펼치시길 바랍니다!
            """)
        elif predicted_paces is None and probability is None : # predict_marathon_strategy에서 주요 오류 발생 시
            st.error("모델 또는 스케일러가 로드되지 않아 예측을 수행할 수 없습니다. 터미널 로그를 확인해주세요.")
        else: # 부분적인 오류 또는 예기치 않은 결과
            st.warning("예측 결과를 생성하는 중 일부 정보가 누락되었습니다. 입력값을 확인하거나 관리자에게 문의하세요.")
            if predicted_paces: st.write("페이스 예측 결과:", predicted_paces)
            if probability is not None : st.write("확률 예측 결과:", probability)

else:
    st.info("👈 왼쪽 사이드바에 정보를 입력하고 '나의 페이스 전략 보기 ✨' 버튼을 클릭하여 결과를 확인하세요!")

# --- 추가 정보 섹션 ---
st.sidebar.markdown("---")
st.sidebar.info("본 서비스는 AI를 활용한 마라톤 페이스 전략 추천 시스템입니다.")
st.sidebar.markdown("Made by **TJ Team** (숭실대학교 데이터사이언스)")