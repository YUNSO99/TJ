import pandas as pd
import numpy as np
import joblib
import json
import os
from datetime import datetime

# --- 설정값 ---
PACE_MODEL_PATH = "./models/pace_prediction_model.pkl"
PROBABILITY_MODEL_PATH = "./models/achievement_probability_model_v2.pkl"
IMPUTATION_VALUES_PATH = "./models/imputation_values.json"

# --- ★★★ 모델별 기대 특성 목록 정의 (매우 중요) ★★★

# 페이스 모델 학습 시 사용된 정확한 특성 목록 (15개로 가정, 실제 학습과 일치 필요)
EXPECTED_PACE_MODEL_FEATURES = [
    'age_numeric', 'M/F', 'Year', 
    'temperature_race', 'humidity_race',
    'user_weekly_km', 'user_target_time_sec', 
    'Dataset_B', 'Dataset_C', 'Dataset_M', 
    'Sub_3', 'Sub_4', 'Sub_5', 'Sub_6', 'Sub_7' # 페이스 모델이 사용한 Sub OHE 컬럼
] # ★★★ 이 리스트의 실제 내용과 길이가 페이스 모델 학습 시와 정확히 일치해야 함 (15개) ★★★

# 확률 모델 (v2) 학습 시 사용된 정확한 특성 목록 (사용자가 제공한 13개 목록 기반)
BASE_PROB_FEATURE_COLUMNS = [
    'age_numeric', 'M/F', 'Year', 
    'temperature_race', 'humidity_race',
    'user_weekly_km', 'user_target_time_sec'
]
DATASET_OHE_COLS = ['Dataset_B', 'Dataset_C', 'Dataset_M'] 

# ★★★ 확률 모델 학습 시 실제 사용된 target_sub_category OHE 컬럼명으로 수정 ★★★
TARGET_SUB_OHE_COLS_FOR_PROB_MODEL = [ 
    'target_sub_category_4', 
    'target_sub_category_5', 
    'target_sub_category_6'
] 
EXPECTED_PROB_MODEL_FEATURES = BASE_PROB_FEATURE_COLUMNS + DATASET_OHE_COLS + TARGET_SUB_OHE_COLS_FOR_PROB_MODEL
# ★★★ 위 조합 결과, 이 리스트의 길이는 정확히 13개가 되어야 함 ★★★


TARGET_PACE_COLUMN_NAMES = [ 
    'target_pace_0_5km', 'target_pace_5_10km', 'target_pace_10_15km', 
    'target_pace_15_Half', 'target_pace_Half_25km', 'target_pace_25_30km', 
    'target_pace_30_35km', 'target_pace_35_40km', 'target_pace_40_finish'
]

# --- 모델 및 전처리기 로드 (이전과 동일) ---
# ... (loaded_pace_model, loaded_probability_model, loaded_scaler, loaded_imputation_values 로드) ...
loaded_pace_model = None
loaded_probability_model = None
loaded_scaler = None
loaded_imputation_values = {}
try:
    loaded_pace_model = joblib.load(PACE_MODEL_PATH)
    print(f"'{PACE_MODEL_PATH}'에서 페이스 예측 모델 로드 완료.")
except Exception as e: print(f"Error loading pace model: {e}")
try:
    prob_model_data = joblib.load(PROBABILITY_MODEL_PATH)
    loaded_probability_model = prob_model_data['model']
    loaded_scaler = prob_model_data['scaler']
    # 모델에 저장된 특성명 리스트 사용 시도 (선택적)
    # if 'features' in prob_model_data and prob_model_data['features']:
    #     EXPECTED_PROB_MODEL_FEATURES = prob_model_data['features']
    #     print(f"'{PROBABILITY_MODEL_PATH}'에서 특성명 리스트를 로드하여 EXPECTED_PROB_MODEL_FEATURES를 업데이트했습니다.")
    print(f"'{PROBABILITY_MODEL_PATH}'에서 확률 예측 모델, 스케일러 로드 완료.")
except Exception as e: print(f"Error loading probability model: {e}")
try:
    with open(IMPUTATION_VALUES_PATH, 'r') as f:
        loaded_imputation_values = json.load(f)
    print(f"'{IMPUTATION_VALUES_PATH}'에서 결측치 대체값 로드 완료.")
except Exception as e: print(f"Error loading imputation values: {e}")


def predict_marathon_strategy(
    age: int,
    sex_str: str, 
    target_time_total_seconds: float,
    temperature: float,
    humidity: float,
    ref_dataset_code: str = 'B'
    # weekly_km, race_year, aspirational_sub_category는 내부에서 기본값/계산값 사용
    ):

    if loaded_pace_model is None or loaded_probability_model is None or loaded_scaler is None:
        print("Error: 모델 또는 스케일러가 로드되지 않아 예측을 수행할 수 없습니다.")
        return None, None, None 

    # --- 내부적으로 사용할 값들 설정 ---
    processed_weekly_km = loaded_imputation_values.get('user_weekly_km', 50.0)
    processed_race_year = datetime.now().year 
    
    def get_sub_category(target_sec): # Sub 또는 target_sub_category 계산용
        if target_sec < 3 * 3600: return 3
        elif target_sec < 4 * 3600: return 4
        elif target_sec < 5 * 3600: return 5
        elif target_sec < 6 * 3600: return 6
        elif target_sec < 7 * 3600: return 7
        return 8 
    processed_sub_for_models = get_sub_category(target_time_total_seconds)


    # --- 1. 모든 가능한 특성을 포함하는 입력 데이터프레임 초기 생성 ---
    all_features_for_input_creation = list(set(EXPECTED_PACE_MODEL_FEATURES + EXPECTED_PROB_MODEL_FEATURES))
    input_data = pd.DataFrame(columns=all_features_for_input_creation, index=[0], dtype=float)
    
    input_data.loc[0, 'age_numeric'] = float(age)
    input_data.loc[0, 'M/F'] = 0 if sex_str == "남성" else 1 
    input_data.loc[0, 'Year'] = int(processed_race_year)
    input_data.loc[0, 'temperature_race'] = float(temperature)
    input_data.loc[0, 'humidity_race'] = float(humidity)
    input_data.loc[0, 'user_weekly_km'] = float(processed_weekly_km)
    input_data.loc[0, 'user_target_time_sec'] = float(target_time_total_seconds)

    # Dataset OHE (공통)
    dataset_col_to_set = f"Dataset_{ref_dataset_code.upper()}"
    for col_prefix in DATASET_OHE_COLS: # DATASET_OHE_COLS는 두 모델 공통 가정
        if col_prefix in input_data.columns:
             input_data.loc[0, col_prefix] = 1 if col_prefix == dataset_col_to_set else 0
    
    # target_sub_category OHE (확률 모델용)
    target_sub_col_to_set = f"target_sub_category_{processed_sub_for_models}"
    for col_prefix in TARGET_SUB_OHE_COLS_FOR_PROB_MODEL: # 확률 모델용 Sub OHE 리스트
        if col_prefix in input_data.columns:
            input_data.loc[0, col_prefix] = 1 if col_prefix == target_sub_col_to_set else 0

    # 페이스 모델용 Sub_X OHE (만약 EXPECTED_PACE_MODEL_FEATURES에 Sub_X가 있다면)
    # 예시: PACE_MODEL_SUB_OHE_COLS = ['Sub_3', 'Sub_4', 'Sub_5', 'Sub_6', 'Sub_7']
    if any(col.startswith("Sub_") for col in EXPECTED_PACE_MODEL_FEATURES):
        pace_sub_col_to_set = f"Sub_{processed_sub_for_models}" 
        for col_prefix in [f"Sub_{i}" for i in range(3, 8)]: # Sub_3 ~ Sub_7 가정
            if col_prefix in input_data.columns and col_prefix in EXPECTED_PACE_MODEL_FEATURES:
                input_data.loc[0, col_prefix] = 1 if col_prefix == pace_sub_col_to_set else 0
    
    # 명시적으로 할당되지 않은 나머지 컬럼 0으로 채우기
    input_data.fillna(0, inplace=True)
    
    # --- 데이터 타입 최종 변환 ---
    final_dtype_conversion_map = {}
    for col in input_data.columns:
        if col == "M/F" or col == "Year" or col.startswith("Dataset_") or col.startswith("target_sub_category_") or col.startswith("Sub_"):
            final_dtype_conversion_map[col] = 'int'
        else: 
            final_dtype_conversion_map[col] = 'float'
    try:
        input_data_processed_full = input_data.astype(final_dtype_conversion_map)
    except Exception as e:
        # ... (오류 처리) ...
        return None, None, None
    
    predicted_paces_sec_per_km = None
    probability_achieved = None
    temp_penalty = 0.0

    # --- 2. 구간별 페이스 예측 ---
    try:
        if not all(f in input_data_processed_full.columns for f in EXPECTED_PACE_MODEL_FEATURES):
            missing = set(EXPECTED_PACE_MODEL_FEATURES) - set(input_data_processed_full.columns)
            raise ValueError(f"페이스 모델 필요 특성 누락: {missing}")
        input_data_for_pace_model = input_data_processed_full[EXPECTED_PACE_MODEL_FEATURES]
        
        predicted_paces_array = loaded_pace_model.predict(input_data_for_pace_model)
        predicted_paces_sec_per_km = dict(zip(TARGET_PACE_COLUMN_NAMES, predicted_paces_array[0]))
    except ValueError as ve: 
        print(f"Error during pace prediction (ValueError): {ve}")
        # ... (오류 로깅) ...
    except Exception as e:
        print(f"Error during pace prediction: {e}")
        
    # --- 3. 목표 달성 확률 예측 ---
    try:
        if not all(f in input_data_processed_full.columns for f in EXPECTED_PROB_MODEL_FEATURES):
            missing = set(EXPECTED_PROB_MODEL_FEATURES) - set(input_data_processed_full.columns)
            raise ValueError(f"확률 모델 필요 특성 누락: {missing}")
        input_data_for_prob_model = input_data_processed_full[EXPECTED_PROB_MODEL_FEATURES]
        
        input_data_scaled = loaded_scaler.transform(input_data_for_prob_model) 
        probability_achieved = loaded_probability_model.predict_proba(input_data_scaled)[0, 1]
    except ValueError as ve: 
        print(f"Error during probability prediction (ValueError): {ve}")
        # ... (오류 로깅) ...
    except Exception as e:
        print(f"Error during probability prediction: {e}")

    # --- 4. 기온 페널티 계산 ---
    if temperature > 12.0: temp_penalty = 0.8 * (temperature - 12.0)
    return predicted_paces_sec_per_km, probability_achieved, temp_penalty

# --- 사용 예시 (main 블록) ---
if __name__ == '__main__':
    sample_user_inputs_app = {
        "age": 35,
        "sex_str": "남성",
        "target_time_total_seconds": 3 * 3600 + 45 * 60, 
        "temperature": 18.0,
        "humidity": 70.0,
        "ref_dataset_code": 'B'
    }
    print("테스트 사용자 입력 (앱에서 전달되는 값):")
    for key, value in sample_user_inputs_app.items():
        print(f"  {key}: {value}")

    paces, prob, penalty = predict_marathon_strategy(**sample_user_inputs_app)
    # (이하 결과 출력은 이전과 동일)
    print("\n--- 최종 예측 결과 ---")
    if paces:
        print("예측된 구간별 페이스 (초/km):")
        for segment, pace_val in paces.items(): 
            minutes = int(pace_val // 60)
            seconds = int(pace_val % 60)
            print(f"  {segment}: {minutes:02d}분 {seconds:02d}초/km (Raw: {pace_val:.2f} sec/km)")
    else:
        print("페이스 예측에 실패했습니다.")

    if prob is not None:
        print(f"목표 달성 확률: {prob*100:.2f}%")
    else:
        print("목표 달성 확률 예측에 실패했습니다.")
        
    print(f"예상 기온 페널티: +{penalty:.2f} 초/km (12°C 초과 시)")

    if paces is None and prob is None:
        print("\n전체 예측 실패. 위에 출력된 오류 메시지와 특성 목록을 확인해주세요.")