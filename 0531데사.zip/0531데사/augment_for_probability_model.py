import pandas as pd
import numpy as np
import os

# --- 설정값 ---
# 원본 데이터 파일 경로 (FINAL_marathons_with_weather.csv)
SOURCE_DATA_PATH = "./FINAL_marathons_with_weather.csv" # ★★★ 실제 경로로 수정하세요 ★★★

# 증강된 데이터 저장 경로
AUGMENTED_DATA_OUTPUT_PATH = "./augmented_prob_model_data.csv" # ★★★ 저장 경로 수정하세요 ★★★

# 가상 목표 시간 시나리오 (초 단위)
# 예시: 3시간, 3시간30분, 4시간, 4시간30분, 5시간
SCENARIO_TARGET_TIMES_SEC = [
    3 * 3600,             # 10800초 (Sub-3)
    3 * 3600 + 30 * 60,   # 12600초 (Sub-3.5)
    4 * 3600,             # 14400초 (Sub-4)
    4 * 3600 + 30 * 60,   # 16200초 (Sub-4.5)
    5 * 3600,             # 18000초 (Sub-5)
    # 필요에 따라 더 다양한 목표 시간 추가 가능
]

# Age_group 처리 함수 (이전과 동일)
def preprocess_age_group(age_group_series: pd.Series) -> pd.Series:
    def convert_age(ag_str):
        ag_str = str(ag_str).strip()
        if ag_str == '19': return 18.0
        elif ag_str == '70': return 72.0
        elif len(ag_str) == 2 and ag_str.isdigit():
            upper_bound = int(ag_str)
            lower_bound = upper_bound - 4
            return (lower_bound + upper_bound) / 2.0
        else: return np.nan
    return age_group_series.apply(convert_age)

# Sub 카테고리 생성 함수 (목표 시간 기반)
def get_sub_category_from_target(target_time_sec):
    if target_time_sec < 3 * 3600: return 3
    elif target_time_sec < 4 * 3600: return 4
    elif target_time_sec < 5 * 3600: return 5
    elif target_time_sec < 6 * 3600: return 6
    elif target_time_sec < 7 * 3600: return 7
    return 8 # 7시간 이상 또는 매우 큰 값 (Sub_8 등으로 처리 가능)


def augment_and_prepare_data_for_prob_model(source_path: str, output_path: str):
    """
    원본 마라톤 데이터를 로드하고, 다양한 목표 시간 시나리오를 적용하여
    확률 모델 학습용 데이터를 증강하고 전처리합니다.
    """
    try:
        print(f"'{source_path}'에서 원본 데이터 로딩 중...")
        df_original = pd.read_csv(source_path, low_memory=False)
        print("원본 데이터 로딩 완료.")
    except FileNotFoundError:
        print(f"FATAL Error: 원본 데이터 파일 '{source_path}'을(를) 찾을 수 없습니다.")
        return
    except Exception as e:
        print(f"FATAL Error: 원본 데이터 로딩 중 오류 발생 - {e}")
        return

    augmented_data_list = []
    
    print(f"{len(SCENARIO_TARGET_TIMES_SEC)}개의 목표 시간 시나리오로 데이터 증강 시작...")
    for index, row in df_original.iterrows():
        if pd.isna(row.get('Final_Time')): # 실제 완주 기록이 없는 경우는 건너뜀
            continue
            
        for target_sec_scenario in SCENARIO_TARGET_TIMES_SEC:
            new_row = row.to_dict()
            new_row['user_target_time_sec'] = target_sec_scenario # 시나리오 목표 시간 설정
            new_row['target_achieved'] = 1 if row['Final_Time'] <= target_sec_scenario else 0
            augmented_data_list.append(new_row)
        
        if (index + 1) % 10000 == 0: # 진행 상황 표시 (10000 행마다)
            print(f"  {index + 1} / {len(df_original)} 행 처리 완료...")
            
    if not augmented_data_list:
        print("Error: 증강된 데이터가 없습니다. 원본 데이터를 확인해주세요.")
        return

    df_augmented = pd.DataFrame(augmented_data_list)
    print(f"데이터 증강 완료. 총 {len(df_augmented)}개의 샘플 생성.")

    # --- 이제 이 증강된 데이터에 `prepare_model_ready_data` 스크립트와 유사한 전처리 적용 ---
    print("\n증강된 데이터에 대한 최종 전처리 시작...")

    # 1. Age_group 처리
    if 'Age_group' in df_augmented.columns:
        df_augmented['age_numeric'] = preprocess_age_group(df_augmented['Age_group'])
    else:
        df_augmented['age_numeric'] = np.nan

    # 2. 사용자 입력 플레이스홀더 (user_weekly_km - 여기서는 아직 값이 없으므로 NaN 유지)
    #    (실제로는 이 값도 시나리오별로 다양하게 설정하거나, 평균 등으로 채울 수 있음)
    if 'user_weekly_km' not in df_augmented.columns:
        df_augmented['user_weekly_km'] = np.nan 

    # 3. 필요한 특성 선택 (모델 학습에 사용할 특성들)
    #    주의: 'Final_Time', 'Sub' (원본) 등은 직접 사용하지 않음 (target_achieved 생성에만 활용)
    #    'Sub' 대신 'user_target_time_sec'로부터 파생된 'target_sub_category'를 OHE하여 사용 가능
    
    # 'user_target_time_sec'를 기반으로 'target_sub_category' 생성
    if 'user_target_time_sec' in df_augmented.columns:
        df_augmented['target_sub_category'] = df_augmented['user_target_time_sec'].apply(get_sub_category_from_target)
    else:
        df_augmented['target_sub_category'] = np.nan


    feature_columns_base = [
        'age_numeric', 'M/F', 'Year', 
        'temperature_race', 'humidity_race',
        'user_weekly_km',             # 학습 시 결측치 처리 필요
        'user_target_time_sec',       # 이제 다양한 값을 가짐!
        'Dataset',                    # OHE 대상
        'target_sub_category'         # OHE 대상 (기존 Sub 대신 사용)
    ]
    # 이 외에 페이스 모델의 예측 결과(구간별 페이스)를 확률 모델의 입력으로 사용할 수도 있습니다.
    # 우선은 위 기본 특성들만 사용합니다.
    
    target_column_prob = 'target_achieved'

    # 실제 존재하는 컬럼만 선택
    final_columns_to_keep = [col for col in feature_columns_base if col in df_augmented.columns] + [target_column_prob]
    df_model_input = df_augmented[final_columns_to_keep].copy()


    # 4. 범주형 변수 원-핫 인코딩 ('Dataset', 'target_sub_category')
    categorical_cols_to_ohe = []
    if 'Dataset' in df_model_input.columns: categorical_cols_to_ohe.append('Dataset')
    if 'target_sub_category' in df_model_input.columns: categorical_cols_to_ohe.append('target_sub_category')

    if categorical_cols_to_ohe:
        df_model_input = pd.get_dummies(df_model_input, columns=categorical_cols_to_ohe, dummy_na=False)
        print(f"범주형 변수 {categorical_cols_to_ohe} 원-핫 인코딩 완료.")

    # 5. 결측치 처리 (user_weekly_km 등)
    #    이 단계는 train_achievement_probability_model 스크립트에서 수행해도 됩니다.
    #    여기서는 간단히 user_weekly_km이 NaN이면 특정 값(예: 평균)으로 채우는 예시만 둡니다.
    if 'user_weekly_km' in df_model_input.columns and df_model_input['user_weekly_km'].isnull().any():
        # 실제로는 학습 데이터의 평균/중앙값 등으로 채워야 함. 여기서는 임의의 값 50으로.
        # 또는 imputation_values.json 파일의 값을 활용.
        # 여기서는 이후 학습 스크립트에서 처리하도록 NaN으로 유지하는 것도 방법.
        # df_model_input['user_weekly_km'].fillna(50.0, inplace=True) 
        print("'user_weekly_km'에 NaN값이 있습니다. 학습 스크립트에서 처리될 예정입니다.")
    
    # 최종 데이터 확인
    print("\n최종 증강 및 전처리된 데이터 정보 (확률 모델 학습용):")
    df_model_input.info()
    print("\n미리보기 (상위 5행):")
    print(df_model_input.head())
    if target_column_prob in df_model_input.columns:
        print(f"\n증강된 '{target_column_prob}' 분포:")
        print(df_model_input[target_column_prob].value_counts(normalize=True, dropna=False))

    # 6. CSV 파일로 저장
    try:
        output_dir = os.path.dirname(output_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        df_model_input.to_csv(output_path, index=False, encoding='utf-8-sig')
        print(f"\n확률 모델 학습용 증강 데이터가 '{output_path}'에 저장되었습니다.")
    except Exception as e:
        print(f"Error: 증강 데이터 CSV 파일 저장 중 오류 발생 - {e}")


if __name__ == '__main__':
    # `os` 모듈 임포트 (필요시)
    # import os 

    augment_and_prepare_data_for_prob_model(
        source_path=SOURCE_DATA_PATH,
        output_path=AUGMENTED_DATA_OUTPUT_PATH
    )