import pandas as pd
import numpy as np
import joblib
import json
import os
from datetime import datetime

# --- 설정값 ---
PACE_MODEL_PATH = "./models/pace_prediction_model.pkl"
PROBABILITY_MODEL_PATH = "./models/achievement_probability_model_v2.pkl" # 재학습된 모델 경로
IMPUTATION_VALUES_PATH = "./models/imputation_values.json"

# --- ★★★ 모델별 기대 특성 목록 정의 (매우 중요) ★★★
# 각 모델 학습 스크립트의 X_train.columns.tolist() 결과와 정확히 일치해야 합니다.

# 페이스 모델 학습 시 사용된 정확한 특성 목록 (예시: 15개로 가정)
# 이 리스트는 pace_prediction_model.pkl 학습 시 사용된 실제 특성들로 채워야 합니다.
# (예시이며, 실제 페이스 모델 학습에 사용된 컬럼으로 정확히 수정해야 합니다.)
EXPECTED_PACE_MODEL_FEATURES = [
    'age_numeric', 'M/F', 'Year', 
    'temperature_race', 'humidity_race',
    'user_weekly_km', 'user_target_time_sec', # 이 특성이 페이스 모델에 사용되었는지 확인
    'Dataset_B', 'Dataset_C', 'Dataset_M', 
    'Sub_3', 'Sub_4', 'Sub_5', 'Sub_6', 'Sub_7' # 페이스 모델이 Sub_X를 사용했다면 포함
] # ★★★ 실제 페이스 모델이 학습한 15개 특성으로 정확히 수정 ★★★

# 확률 모델 (v2) 학습 시 사용된 정확한 특성 목록 (사용자가 제공한 13개 목록)
EXPECTED_PROB_MODEL_FEATURES = [
    'age_numeric', 'M/F', 'Year', 
    'temperature_race', 'humidity_race',
    'user_weekly_km', 'user_target_time_sec',
    'Dataset_B', 'Dataset_C', 'Dataset_M', 
    'target_sub_category_4', 'target_sub_category_5', 'target_sub_category_6'
] # ★★★ 사용자가 제공한 13개 특성 목록과 정확히 일치 ★★★


# 페이스 모델의 출력 목표 변수명 (순서 중요)
TARGET_PACE_COLUMN_NAMES = [
    'target_pace_0_5km', 'target_pace_5_10km', 'target_pace_10_15km', 
    'target_pace_15_Half', 'target_pace_Half_25km', 'target_pace_25_30km', 
    'target_pace_30_35km', 'target_pace_35_40km', 'target_pace_40_finish'
]

# --- 모델 및 전처리기 로드 ---
loaded_pace_model = None
loaded_probability_model = None
loaded_scaler = None
loaded_imputation_values = {}

try:
    loaded_pace_model = joblib.load(PACE_MODEL_PATH)
    print(f"'{PACE_MODEL_PATH}'에서 페이스 예측 모델 로드 완료.")
except FileNotFoundError:
    print(f"Warning: 페이스 예측 모델 파일을 찾을 수 없습니다: {PACE_MODEL_PATH}")
except Exception as e:
    print(f"Error loading pace model: {e}")

try:
    prob_model_data = joblib.load(PROBABILITY_MODEL_PATH)
    loaded_probability_model = prob_model_data['model']
    loaded_scaler = prob_model_data['scaler']
    # 모델 저장 시 'features' 키로 특성명 리스트를 저장했다면, 여기서 로드하여 EXPECTED_PROB_MODEL_FEATURES로 사용 가능
    # loaded_prob_model_features = prob_model_data.get('features')
    # if loaded_prob_model_features:
    #     EXPECTED_PROB_MODEL_FEATURES = loaded_prob_model_features 
    print(f"'{PROBABILITY_MODEL_PATH}'에서 확률 예측 모델, 스케일러 로드 완료.")
except FileNotFoundError:
    print(f"Warning: 확률 예측 모델 파일을 찾을 수 없습니다: {PROBABILITY_MODEL_PATH}")
except Exception as e:
    print(f"Error loading probability model: {e}")

try:
    with open(IMPUTATION_VALUES_PATH, 'r') as f:
        loaded_imputation_values = json.load(f)
    print(f"'{IMPUTATION_VALUES_PATH}'에서 결측치 대체값 로드 완료.")
except FileNotFoundError:
    print(f"Warning: 결측치 대체값 파일을 찾을 수 없습니다: {IMPUTATION_VALUES_PATH}. 기본 대체값을 사용합니다.")
except Exception as e:
    print(f"Error loading imputation values: {e}")


def predict_marathon_strategy(
    age: int,
    sex_str: str, 
    weekly_km: float,
    target_time_total_seconds: float,
    temperature: float,
    humidity: float,
    race_year: int = datetime.now().year, 
    ref_dataset_code: str = 'B', 
    aspirational_sub_category: int = 4 # 확률 모델의 target_sub_category_X 용
    # 만약 페이스 모델이 이전 Sub_X를 사용한다면, 해당 입력도 인자로 추가 필요
    # 예: aspirational_sub_category_for_pace: int = 4
    ):

    if loaded_pace_model is None or loaded_probability_model is None or loaded_scaler is None:
        print("Error: 모델 또는 스케일러가 로드되지 않아 예측을 수행할 수 없습니다.")
        return None, None, None 

    # --- 1. 모든 가능한 특성을 포함하는 입력 데이터프레임 초기 생성 ---
    # 두 모델이 사용하는 모든 특성명을 일단 다 포함시켜서 DataFrame 틀을 만듭니다.
    all_features_in_models = list(set(EXPECTED_PACE_MODEL_FEATURES + EXPECTED_PROB_MODEL_FEATURES))
    input_data = pd.DataFrame(columns=all_features_in_models, index=[0], dtype=float) # dtype을 float으로 초기화

    # --- 사용자 입력값 및 기본 정보 할당 ---
    input_data.loc[0, 'age_numeric'] = float(age)
    input_data.loc[0, 'M/F'] = 0 if sex_str == "남성" else 1 
    input_data.loc[0, 'Year'] = int(race_year)
    input_data.loc[0, 'temperature_race'] = float(temperature)
    input_data.loc[0, 'humidity_race'] = float(humidity)
    
    input_data.loc[0, 'user_weekly_km'] = float(weekly_km) if weekly_km is not None else loaded_imputation_values.get('user_weekly_km', 50.0)
    input_data.loc[0, 'user_target_time_sec'] = float(target_time_total_seconds) if target_time_total_seconds is not None else loaded_imputation_values.get('user_target_time_sec', 14400.0)

    # --- OHE 컬럼들 채우기 ---
    # Dataset OHE (페이스/확률 모델 공통 가정)
    dataset_col_to_set = f"Dataset_{ref_dataset_code.upper()}"
    for col_prefix in ['Dataset_B', 'Dataset_C', 'Dataset_M']: # 실제 사용된 OHE 컬럼명 확인
        if col_prefix in input_data.columns:
            input_data.loc[0, col_prefix] = 1 if col_prefix == dataset_col_to_set else 0
    
    # target_sub_category OHE (확률 모델용)
    target_sub_col_to_set = f"target_sub_category_{aspirational_sub_category}"
    for col_prefix in ['target_sub_category_3', 'target_sub_category_4', 'target_sub_category_5', 'target_sub_category_6', 'target_sub_category_7', 'target_sub_category_8']:
        if col_prefix in input_data.columns: # 이 컬럼들이 EXPECTED_PROB_MODEL_FEATURES에 있을 때만 채움
            input_data.loc[0, col_prefix] = 1 if col_prefix == target_sub_col_to_set else 0

    # 페이스 모델용 Sub_X OHE (만약 페이스 모델이 이를 사용한다면)
    # 예를 들어 EXPECTED_PACE_MODEL_FEATURES에 'Sub_3', 'Sub_4' 등이 포함되어 있다면,
    # aspirational_sub_category 값을 사용하여 해당 Sub_X 컬럼들을 채워줘야 합니다.
    # 예시:
    # pace_sub_col_to_set = f"Sub_{aspirational_sub_category}" 
    # for col_prefix in ['Sub_3', 'Sub_4', 'Sub_5', 'Sub_6', 'Sub_7']: # 실제 페이스 모델이 사용한 Sub OHE 컬럼명
    #     if col_prefix in input_data.columns and col_prefix in EXPECTED_PACE_MODEL_FEATURES:
    #         input_data.loc[0, col_prefix] = 1 if col_prefix == pace_sub_col_to_set else 0


    # input_data에 정의되지 않은 (EXPECTED_..._FEATURES에만 있는) 컬럼들을 0으로 채우기
    for col in all_features_in_models:
        if col not in input_data.columns: # 이런 경우는 없어야 함 (위에서 columns=all_features_in_models 로 생성)
             input_data[col] = 0 
        elif input_data[col].isnull().all(): # 생성은 되었으나 값이 할당 안된 컬럼 (주로 OHE 중 해당 안되는 것)
             input_data[col] = 0
    
    # --- 데이터 타입 최종 변환 (모델별 특성 선택 전에 일괄적으로) ---
    # 이 변환은 모든 컬럼에 대해 수행하고, 각 모델에 전달 전 필요한 컬럼만 선택합니다.
    final_dtype_conversion_map = {}
    for col in input_data.columns: # 현재 input_data에 있는 모든 컬럼에 대해
        if col == "M/F" or col == "Year" or col.startswith("Dataset_") or col.startswith("target_sub_category_") or col.startswith("Sub_"):
            final_dtype_conversion_map[col] = 'int'
        else: 
            final_dtype_conversion_map[col] = 'float'
    
    try:
        input_data_processed_full = input_data.astype(final_dtype_conversion_map)
        print("\nInput data (full, for selection) dtypes after conversion:")
        print(input_data_processed_full.dtypes)
    except Exception as e:
        print(f"FATAL Error: Failed to convert input data dtypes: {e}")
        print("Data before error:")
        print(input_data.head(1).to_dict(orient='records'))
        return None, None, None
    
    predicted_paces_sec_per_km = None
    probability_achieved = None
    temp_penalty = 0.0

    # --- 2. 구간별 페이스 예측 ---
    try:
        # 페이스 모델이 기대하는 특성만, 정확한 순서대로 선택
        if not all(f in input_data_processed_full.columns for f in EXPECTED_PACE_MODEL_FEATURES):
            missing = set(EXPECTED_PACE_MODEL_FEATURES) - set(input_data_processed_full.columns)
            raise ValueError(f"페이스 모델에 필요한 일부 특성이 준비된 데이터에 없습니다. 누락: {missing}")
            
        input_data_for_pace_model = input_data_processed_full[EXPECTED_PACE_MODEL_FEATURES]
        print(f"\nFeatures for Pace Model ({len(input_data_for_pace_model.columns)}): {input_data_for_pace_model.columns.tolist()}")
        
        predicted_paces_array = loaded_pace_model.predict(input_data_for_pace_model)
        predicted_paces_sec_per_km = dict(zip(TARGET_PACE_COLUMN_NAMES, predicted_paces_array[0]))
        # print(f"예측된 구간별 페이스 (초/km): {predicted_paces_sec_per_km}") # 성공 시 메인 블록에서 출력
    except ValueError as ve: 
        print(f"Error during pace prediction (ValueError): {ve}")
        # 페이스 모델의 n_features_in_ 속성으로 기대 특성 수 확인 (LightGBM sklearn wrapper)
        if hasattr(loaded_pace_model, 'n_features_in_'): # MultiOutputRegressor의 경우 estimator의 속성 확인
            estimator_n_features = getattr(loaded_pace_model.estimator_, 'n_features_in_', 'N/A (estimator)')
            print(f"   Pace model (estimator) expected {estimator_n_features} features.")
        elif hasattr(loaded_pace_model, '_n_features_out') and hasattr(loaded_pace_model, 'estimators_') and len(loaded_pace_model.estimators_) > 0: # MultiOutputRegressor
             print(f"   Pace model (MultiOutput) estimator expected {loaded_pace_model.estimators_[0].n_features_in_} features.")

        print(f"   Provided {len(input_data_for_pace_model.columns)} features: {input_data_for_pace_model.columns.tolist()}")
    except Exception as e:
        print(f"Error during pace prediction: {e}")
        
    # --- 3. 목표 달성 확률 예측 ---
    try:
        # 확률 모델이 기대하는 특성만, 정확한 순서대로 선택
        if not all(f in input_data_processed_full.columns for f in EXPECTED_PROB_MODEL_FEATURES):
            missing = set(EXPECTED_PROB_MODEL_FEATURES) - set(input_data_processed_full.columns)
            raise ValueError(f"확률 모델에 필요한 일부 특성이 준비된 데이터에 없습니다. 누락: {missing}")

        input_data_for_prob_model = input_data_processed_full[EXPECTED_PROB_MODEL_FEATURES]
        print(f"\nFeatures for Probability Model ({len(input_data_for_prob_model.columns)}): {input_data_for_prob_model.columns.tolist()}")
        
        input_data_scaled = loaded_scaler.transform(input_data_for_prob_model) 
        probability_achieved = loaded_probability_model.predict_proba(input_data_scaled)[0, 1]
        # print(f"예측된 목표 달성 확률: {probability_achieved:.4f}") # 성공 시 메인 블록에서 출력
    except ValueError as ve: 
        print(f"Error during probability prediction (ValueError): {ve}")
        if hasattr(loaded_scaler, 'n_features_in_'):
             print(f"  Scaler expected {loaded_scaler.n_features_in_} features.")
        if hasattr(loaded_probability_model, 'n_features_in_'):
             print(f"  Probability model expected {loaded_probability_model.n_features_in_} features.")
        print(f"  Provided {len(input_data_for_prob_model.columns)} features: {input_data_for_prob_model.columns.tolist()}")
    except Exception as e:
        print(f"Error during probability prediction: {e}")

    # --- 4. 기온 페널티 계산 ---
    if temperature > 12.0:
        temp_penalty = 0.8 * (temperature - 12.0)
    
    return predicted_paces_sec_per_km, probability_achieved, temp_penalty

# --- 사용 예시 (main 블록) ---
if __name__ == '__main__':
    sample_user_inputs = {
        "age": 35,
        "sex_str": "남성",
        "weekly_km": 60.0,
        "target_time_total_seconds": 3 * 3600 + 45 * 60, # 3시간 45분
        "temperature": 18.0,
        "humidity": 70.0,
        "race_year": datetime.now().year,
        "ref_dataset_code": 'B', 
        "aspirational_sub_category": 4 
    }
    print("테스트 사용자 입력:")
    for key, value in sample_user_inputs.items():
        print(f"  {key}: {value}")

    paces, prob, penalty = predict_marathon_strategy(**sample_user_inputs)

    print("\n--- 최종 예측 결과 ---")
    if paces:
        print("예측된 구간별 페이스 (초/km):")
        for segment, pace_val in paces.items(): 
            minutes = int(pace_val // 60)
            seconds = int(pace_val % 60)
            print(f"  {segment}: {minutes:02d}분 {seconds:02d}초/km (Raw: {pace_val:.2f} sec/km)")
    else:
        print("페이스 예측에 실패했습니다.")

    if prob is not None: # 확률은 0일 수도 있으므로 None 체크
        print(f"목표 달성 확률: {prob*100:.2f}%")
    else:
        print("목표 달성 확률 예측에 실패했습니다.")
        
    print(f"예상 기온 페널티: +{penalty:.2f} 초/km (12°C 초과 시)")

    if paces is None and prob is None:
        print("\n전체 예측 실패. 위에 출력된 오류 메시지와 특성 목록을 확인해주세요.")