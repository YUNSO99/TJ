import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime

# prediction_pipeline.py에서 예측 함수 및 필요한 상수 가져오기
# (prediction_pipeline.py가 app.py와 같은 디렉토리에 있다고 가정)
try:
    from prediction_pipeline import predict_marathon_strategy, TARGET_PACE_COLUMN_NAMES
except ImportError:
    st.error("오류: 'prediction_pipeline.py' 파일을 찾을 수 없거나, 해당 파일에서 필요한 함수/상수를 가져올 수 없습니다. 파일 위치와 내용을 확인해주세요.")
    # 사용자가 prediction_pipeline.py의 내용을 직접 여기에 붙여넣거나,
    # 파일 경로 문제를 해결해야 합니다.
    # 임시로 함수 실행을 막기 위해 st.stop() 사용 가능
    st.stop() 


# --- 페이지 기본 설정 ---
st.set_page_config(
    page_title="마라톤 페이스 전략 AI",
    page_icon="🏃‍♂️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- 대시보드 제목 및 소개 ---
st.title("AI 기반 개인 맞춤형 마라톤 페이스 전략 🏃‍♀️💨")
st.markdown("""
당신의 목표와 컨디션, 예상되는 레이스 환경을 입력하고,
AI가 추천하는 최적의 구간별 페이스와 목표 달성 가능성을 확인해보세요!
이 전략은 수만 건의 실제 마라톤 기록과 날씨 데이터를 학습한 모델을 기반으로 제공됩니다.
""")
st.markdown("---")

# --- 사용자 정보 입력 섹션 (사이드바) ---
with st.sidebar:
    st.header("🏁 레이스 정보 입력")

    sex_options = ["남성", "여성"]
    sex_str_input = st.selectbox("성별 (Sex)", sex_options, help="성별을 선택해주세요.")

    age_input = st.number_input("나이 (Age)", min_value=18, max_value=99, value=30, step=1, help="만 나이를 입력해주세요.")
    
    weekly_km_input = st.slider("주간 평균 달리기 거리 (km)", min_value=0.0, max_value=200.0, value=50.0, step=5.0, format="%.1f", help="최근 한 달간의 주 평균 달리기 거리를 입력해주세요.")

    st.subheader("🎯 목표 완주 시간")
    target_hours = st.number_input("시간 (Hours)", min_value=2, max_value=7, value=4, step=1, key="th", help="목표 완주 시간의 '시'를 입력하세요.")
    target_minutes = st.number_input("분 (Minutes)", min_value=0, max_value=59, value=0, step=1, key="tm", help="목표 완주 시간의 '분'을 입력하세요.")
    target_seconds = st.number_input("초 (Seconds)", min_value=0, max_value=59, value=0, step=1, key="ts", help="목표 완주 시간의 '초'를 입력하세요.")
    
    target_time_total_seconds_input = (target_hours * 3600) + (target_minutes * 60) + target_seconds

    st.subheader("☀️ 예상 날씨")
    temperature_input = st.slider("평균 기온 (°C)", min_value=-10.0, max_value=40.0, value=15.0, step=0.5, format="%.1f", help="레이스 시간 동안 예상되는 평균 기온을 입력하세요.")
    humidity_input = st.slider("평균 습도 (%)", min_value=0, max_value=100, value=60, step=1, help="레이스 시간 동안 예상되는 평균 상대 습도를 입력하세요.")

    st.subheader("⚙️ 추가 설정 (선택 사항)")
    current_year = datetime.now().year
    race_year_input = st.number_input("레이스 연도 (Race Year)", min_value=current_year, max_value=current_year + 5, value=current_year, step=1, help="레이스가 열리는 연도를 선택하세요.")
    
    dataset_options_map = {
        "보스턴 마라톤 코스 유형": 'B',
        "모스크바 마라톤 코스 유형": 'M',
        "시카고 마라톤 코스 유형": 'C'
    }
    ref_dataset_str = st.selectbox(
        "참고 코스 유형 (Reference Course Type)", 
        options=list(dataset_options_map.keys()), 
        index=0, # 기본값 보스턴
        help="예상하는 레이스 코스와 가장 유사한 유형을 선택해주세요. 모델 예측에 참고됩니다."
    )
    ref_dataset_code_input = dataset_options_map[ref_dataset_str]

    sub_options = [3, 4, 5, 6, 7] # Sub-3, Sub-4 등
    aspirational_sub_category_input = st.selectbox(
        "목표 Sub 기록 그룹 (Aspirational Sub-X)", 
        options=sub_options, 
        index=1, # 기본값 Sub-4
        format_func=lambda x: f"Sub-{x} 그룹 목표",
        help="달성하고자 하는 목표 기록이 속하는 시간대 그룹을 선택해주세요 (예: 3시간 45분 목표 시 Sub-4)."
    )

    submit_button = st.button("나의 페이스 전략 보기 ✨")

# --- 결과 표시 섹션 (메인 화면) ---
if submit_button:
    if not TARGET_PACE_COLUMN_NAMES: # prediction_pipeline에서 상수가 제대로 로드 안된 경우
        st.error("오류: 목표 페이스 컬럼명(`TARGET_PACE_COLUMN_NAMES`)이 `prediction_pipeline.py`에 올바르게 정의되지 않았습니다.")
    else:
        with st.spinner("AI가 최적의 페이스 전략을 계산 중입니다... 잠시만 기다려주세요 🤔"):
            predicted_paces, probability, temp_penalty = predict_marathon_strategy(
                age=age_input,
                sex_str=sex_str_input,
                weekly_km=weekly_km_input,
                target_time_total_seconds=target_time_total_seconds_input,
                temperature=temperature_input,
                humidity=humidity_input,
                race_year=race_year_input,
                ref_dataset_code=ref_dataset_code_input,
                aspirational_sub_category=aspirational_sub_category_input
            )

        if predicted_paces and probability is not None: # probability는 0일 수 있으므로 is not None 체크
            st.subheader("📈 당신을 위한 맞춤형 마라톤 전략 결과")

            # 1. 핵심 요약 정보
            col1, col2 = st.columns(2)
            with col1:
                st.metric(label="🎯 목표 달성 예상 확률", value=f"{probability*100:.2f}%")
                st.progress(int(probability*100))
            
            # 추천 페이스 기반 총 예상 완주 시간 계산
            # (주의: TARGET_PACE_COLUMN_NAMES 순서와 predicted_paces 딕셔너리 키 순서가 일치해야 함)
            # 또한, 각 구간의 정확한 거리가 필요합니다. 여기서는 5km로 가정하고 마지막만 2.195km로 합니다.
            segment_distances_km = [5, 5, 5, 0, 0, 5, 5, 5, 2.195] # ★★★ 실제 구간 정의에 맞게 수정 필요! ★★★
            # 'target_pace_15_Half', 'target_pace_Half_25km'에 대한 정확한 거리 계산 필요
            # 예시: 15km -> Half (21.0975km) = 6.0975km, Half -> 25km = 3.9025km
            # 아래는 예시이며, TARGET_PACE_COLUMN_NAMES와 순서 및 개수를 정확히 맞춰야 합니다.
            # 이 부분은 TARGET_PACE_COLUMN_NAMES의 실제 구간 정의에 따라 정확한 거리를 매핑해야 합니다.
            # 간단하게, 9개 구간이 모두 42.195/9 km 라고 가정하거나,
            # 아니면 각 pace_target 컬럼명에서 구간을 파싱하여 거리를 계산해야 합니다.
            # 우선은 각 구간별 페이스만 보여주고, 총 시간은 사용자가 직접 계산하도록 유도하거나,
            # 또는 정확한 구간 거리 정보를 prediction_pipeline에서 함께 반환하는 것이 좋습니다.
            
            # 임시: 총 예상 시간은 아래 표에서 누적 시간으로 확인하도록 안내
            # total_predicted_seconds = 0
            # for i, key in enumerate(TARGET_PACE_COLUMN_NAMES):
            #     if key in predicted_paces and segment_distances_km[i] > 0 : # segment_distances_km 수정 필요
            #         total_predicted_seconds += predicted_paces[key] * segment_distances_km[i]
            
            # predicted_h = int(total_predicted_seconds // 3600)
            # predicted_m = int((total_predicted_seconds % 3600) // 60)
            # predicted_s = int(total_predicted_seconds % 60)
            # predicted_total_time_str = f"{predicted_h:02d}시간 {predicted_m:02d}분 {predicted_s:02d}초"
            # with col2:
            #     st.metric(label="⏱️ 추천 페이스 기반 예상 완주 시간", value=predicted_total_time_str)


            # 2. 열 스트레스 및 기온 페널티
            heat_stress_level = "낮음"
            advice = "수분 섭취에 유의하며 레이스를 즐기세요!"
            if temperature_input >= 30 or (temperature_input >= 25 and humidity_input >= 70):
                heat_stress_level = "매우 높음 🥵"
                advice = "탈수 및 열 관련 질환 위험이 매우 높습니다! 레이스 참여를 재고하거나 목표를 대폭 수정하고, 충분한 수분 섭취와 휴식이 필수입니다."
                st.error(f"열 스트레스: {heat_stress_level} {advice}")
            elif temperature_input >= 25 or (temperature_input >= 20 and humidity_input >= 80):
                heat_stress_level = "높음 🌡️"
                advice = "상당한 열 스트레스가 예상됩니다. 수분 섭취에 각별히 신경 쓰고, 페이스를 평소보다 보수적으로 운영하세요."
                st.warning(f"열 스트레스: {heat_stress_level} {advice}")
            elif temperature_input >= 20 or (temperature_input >= 15 and humidity_input >= 90): # 습도 기준 강화
                heat_stress_level = "주의 😥"
                advice = "다소 더위를 느낄 수 있습니다. 수분 섭취 계획을 잘 세우고, 몸 상태를 주시하세요."
                st.info(f"열 스트레스: {heat_stress_level} {advice}")
            else:
                st.success(f"쾌적한 레이스가 예상됩니다! (열 스트레스 {heat_stress_level})")
            
            st.caption(f"예상 기온 페널티: 약 +{temp_penalty:.1f} 초/km (12°C 초과 시)")
            st.markdown("---")

            # 3. 구간별 추천 페이스 상세
            st.markdown("####  구간별 추천 페이스 전략")
            
            pace_display_data = []
            # ★★★ 아래 segment_names와 segment_lengths_km는 TARGET_PACE_COLUMN_NAMES에 맞춰 정확히 정의해야 합니다. ★★★
            segment_names = [ # TARGET_PACE_COLUMN_NAMES의 순서와 일치해야 함
                "0-5km", "5-10km", "10-15km", "15km-하프", "하프-25km", 
                "25-30km", "30-35km", "35-40km", "40km-완주"
            ]
            segment_lengths_km = [ # 각 구간의 실제 거리 (km)
                5.0, 5.0, 5.0, 21.0975 - 15.0, 25.0 - 21.0975,
                5.0, 5.0, 5.0, 42.195 - 40.0
            ]
            if len(segment_names) != len(TARGET_PACE_COLUMN_NAMES) or len(segment_lengths_km) != len(TARGET_PACE_COLUMN_NAMES):
                st.error("오류: `segment_names` 또는 `segment_lengths_km`의 길이가 `TARGET_PACE_COLUMN_NAMES`와 일치하지 않습니다. 코드 점검이 필요합니다.")
            else:
                cumulative_time_sec = 0
                for i, key in enumerate(TARGET_PACE_COLUMN_NAMES):
                    pace_sec_km = predicted_paces.get(key, 0) # 해당 키가 없으면 0으로 처리 (오류 방지)
                    minutes = int(pace_sec_km // 60)
                    seconds = int(pace_sec_km % 60)
                    
                    segment_time_sec = pace_sec_km * segment_lengths_km[i]
                    cumulative_time_sec += segment_time_sec
                    
                    seg_h = int(segment_time_sec // 3600)
                    seg_m = int((segment_time_sec % 3600) // 60)
                    seg_s = int(segment_time_sec % 60)
                    
                    cum_h = int(cumulative_time_sec // 3600)
                    cum_m = int((cumulative_time_sec % 3600) // 60)
                    cum_s = int(cumulative_time_sec % 60)

                    pace_display_data.append({
                        "구간": segment_names[i],
                        "추천 페이스 (분:초/km)": f"{minutes:02d}:{seconds:02d}",
                        "구간 예상 시간": f"{seg_h:02d}시 {seg_m:02d}분 {seg_s:02d}초" if seg_h > 0 else f"{seg_m:02d}분 {seg_s:02d}초",
                        "누적 예상 시간": f"{cum_h:02d}시 {cum_m:02d}분 {cum_s:02d}초"
                    })
                
                pace_df = pd.DataFrame(pace_display_data)
                st.table(pace_df)

                # 추천 페이스 기반 총 예상 완주 시간 (표의 마지막 누적 시간으로 대체 또는 여기서 다시 표시)
                if cumulative_time_sec > 0 and 'col2' in locals() : # col2가 정의된 경우에만 시도 (위의 st.columns)
                     with col2: # 예상 완주 시간을 확률 옆에 표시
                         st.metric(label="⏱️ 추천 페이스 기반 예상 완주 시간", value=f"{cum_h:02d}시 {cum_m:02d}분 {cum_s:02d}초")


                # 4. 페이스 변화 시각화
                st.markdown("#### 페이스 변화 그래프 (초/km)")
                chart_data_list = []
                for i, key in enumerate(TARGET_PACE_COLUMN_NAMES):
                    chart_data_list.append({'구간': segment_names[i], '페이스 (초/km)': predicted_paces.get(key, 0)})
                
                chart_df = pd.DataFrame(chart_data_list)
                st.line_chart(chart_df.set_index('구간'))

            st.markdown("---")
            st.info("""
            **💡 참고 및 주의사항:**
            * 이 추천은 입력된 정보와 과거 데이터를 기반으로 한 통계적 예측입니다.
            * 실제 레이스 중 개인의 컨디션, 예상치 못한 날씨 변화, 코스 상세 특성(고도 등)에 따라 페이스 조절이 필요할 수 있습니다.
            * 항상 자신의 몸에 귀 기울이며 안전하고 즐거운 레이스를 펼치시길 바랍니다!
            """)
        else:
            st.error("예측 결과를 생성하는 중 오류가 발생했습니다. 입력값을 확인하거나 관리자에게 문의하세요.")
            # 상세 오류는 터미널/로그에서 확인
else:
    st.info("👈 왼쪽 사이드바에 정보를 입력하고 '나의 페이스 전략 보기 ✨' 버튼을 클릭하세요!")

# --- (선택 사항) 추가 정보 섹션 ---
st.sidebar.markdown("---")
st.sidebar.markdown("Made by **TJ Team** (숭실대학교 데이터사이언스팀플)")
st.sidebar.markdown("Powered by AI & Your Passion for Running!")