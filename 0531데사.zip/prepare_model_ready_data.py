import pandas as pd
import numpy as np

def preprocess_age_group(age_group_series: pd.Series) -> pd.Series:
    """'Age_group' 문자열을 대표 숫자 나이로 변환합니다."""
    def convert_age(ag_str):
        ag_str = str(ag_str).strip() # 문자열로 변환하고 공백 제거
        if ag_str == '19': # 19세 이하
            return 18 # 또는 19
        elif ag_str == '70': # 70세 이상
            return 72 # 또는 70
        elif len(ag_str) == 2 and ag_str.isdigit(): # 예: '29' (25-29세), '34' (30-34세)
            upper_bound = int(ag_str)
            lower_bound = upper_bound - 4
            return (lower_bound + upper_bound) / 2
        else:
            return np.nan # 그 외 알 수 없는 값
    return age_group_series.apply(convert_age)

def prepare_model_ready_data(input_csv_path: str, output_csv_path: str):
    """
    FINAL_marathons_with_weather.csv 파일을 읽어 모델 학습에 필요한
    최종 특성 및 목표 변수를 만들고 정제하여 새 CSV로 저장합니다.
    """
    try:
        print(f"'{input_csv_path}' 파일 로딩 중...")
        df = pd.read_csv(input_csv_path, low_memory=False)
        print("파일 로딩 완료.")
    except FileNotFoundError:
        print(f"FATAL Error: 입력 파일 '{input_csv_path}'을(를) 찾을 수 없습니다.")
        return
    except Exception as e:
        print(f"FATAL Error: 파일 로딩 중 오류 발생 - {e}")
        return

    # --- 1. Age_group 처리 ---
    if 'Age_group' in df.columns:
        df['age_numeric'] = preprocess_age_group(df['Age_group'])
        print("'Age_group'을 'age_numeric'으로 변환 완료.")
    else:
        print("Warning: 'Age_group' 컬럼이 없습니다.")
        df['age_numeric'] = np.nan # 컬럼이 없으면 NaN으로 생성

    # --- 2. 목표 변수 (구간별 페이스) 정의 및 생성 ---
    # 기존 Xp 컬럼들을 목표 변수로 사용하고, 이름 변경
    # (5p, 10p, 15p, Halfp, 25p, 30p, 35p, 40p 순서로 가정)
    # Halfp는 어느 구간인지 명확한 정의가 필요하나, 일단 그대로 사용
    pace_target_cols_original = ['5p', '10p', '15p', 'Halfp', '25p', '30p', '35p', '40p']
    pace_target_cols_new = [
        'target_pace_0_5km', 'target_pace_5_10km', 'target_pace_10_15km', 
        'target_pace_15_Half', # 또는 Halfp의 정확한 구간명으로 변경 필요
        'target_pace_Half_25km',# 또는 25p의 정확한 구간명으로 변경 필요
        'target_pace_25_30km', 'target_pace_30_35km', 'target_pace_35_40km'
    ]

    # 실제 존재하는 컬럼만 이름 변경 시도
    rename_dict = {}
    for old, new in zip(pace_target_cols_original, pace_target_cols_new):
        if old in df.columns:
            rename_dict[old] = new
        else:
            print(f"Warning: 목표 변수용 페이스 컬럼 '{old}'가 원본 데이터에 없습니다. 해당 목표 변수는 생성되지 않습니다.")
    df.rename(columns=rename_dict, inplace=True)
    
    # 마지막 구간 (40km ~ 완주) 페이스 계산
    # 풀코스 거리 정의 (km)
    FULL_MARATHON_DISTANCE_KM = 42.195 
    if 'Final_Time' in df.columns and '40K' in df.columns:
        # 40km 이후 남은 거리 (km)
        remaining_distance_km = FULL_MARATHON_DISTANCE_KM - 40.0
        # 40km 이후 걸린 시간 (sec)
        time_after_40k_sec = df['Final_Time'] - df['40K']
        # 40km 이후 페이스 (sec/km)
        # 남은 거리가 0보다 크고, 시간도 양수인 경우에만 계산
        df['target_pace_40_finish'] = np.where(
            (remaining_distance_km > 0) & (time_after_40k_sec >= 0) & (df['40K'] <= df['Final_Time']),
            time_after_40k_sec / remaining_distance_km,
            np.nan
        )
        pace_target_cols_new.append('target_pace_40_finish')
        print("마지막 구간(40km-완주) 페이스 계산 완료.")
    else:
        print("Warning: 'Final_Time' 또는 '40K' 컬럼이 없어 마지막 구간 페이스를 계산할 수 없습니다.")

    # 생성된 실제 목표 변수 컬럼 목록
    final_pace_target_columns = [col for col in pace_target_cols_new if col in df.columns]
    if not final_pace_target_columns:
        print("Error: 생성된 목표 페이스 변수가 하나도 없습니다. Xp 또는 XK 컬럼명을 확인해주세요.")


    # --- 3. 입력 특성(X) 선택 및 가공 ---
    # 사용자 입력 플레이스홀더 추가 (모델 학습 시에는 NaN 또는 특정값으로, 예측 시에는 사용자 입력 사용)
    df['user_weekly_km'] = np.nan # 사용자가 입력할 주간 평균 달리기 거리
    df['user_target_time_sec'] = np.nan # 사용자가 입력할 목표 완주 시간 (초)

    feature_columns = [
        'age_numeric', 
        'M/F', # 이미 0/1로 인코딩 되어있다고 가정
        'Dataset', # 범주형 -> 원-핫 인코딩 필요
        'Year', 
        'temperature_race', 
        'humidity_race',
        'Sub', # 범주형 -> 원-핫 인코딩 필요
        'user_weekly_km',
        'user_target_time_sec'
    ]
    
    # 실제 존재하는 특성 컬럼만 선택
    existing_feature_columns = [col for col in feature_columns if col in df.columns]
    if len(existing_feature_columns) != len(feature_columns):
        print(f"Warning: 일부 기본 특성 컬럼이 원본 데이터에 없습니다. 있는 컬럼만 사용합니다: {existing_feature_columns}")

    # 최종 사용할 특성과 목표 변수만 선택
    df_model_ready = df[existing_feature_columns + final_pace_target_columns].copy()

    # 범주형 변수 원-핫 인코딩 (Dataset, Sub)
    categorical_cols = []
    if 'Dataset' in df_model_ready.columns: categorical_cols.append('Dataset')
    if 'Sub' in df_model_ready.columns: categorical_cols.append('Sub')
    
    if categorical_cols:
        df_model_ready = pd.get_dummies(df_model_ready, columns=categorical_cols, dummy_na=False) # dummy_na=False: NaN에 대한 더미 변수 생성 안함
        print(f"범주형 변수 {categorical_cols} 원-핫 인코딩 완료.")
    
    # --- 4. 결측치 처리 ---
    # 목표 변수에 결측치가 있는 행은 예측/학습이 불가능하므로 우선 제거 (또는 다른 정교한 처리)
    if final_pace_target_columns:
        # 모든 목표 페이스 컬럼에 대해 결측치가 없는 행만 남기거나, 일부만 있는 경우도 고려 가능
        # 여기서는 가장 중요한 첫번째 목표 페이스 컬럼이 NaN인 경우만 우선 제거
        # 또는, 모든 목표 페이스가 NaN인 경우 제거
        # df_model_ready.dropna(subset=final_pace_target_columns, how='all', inplace=True)
        # 혹은, 주요 페이스 (예: 첫 구간)에 NaN이 있으면 제거
        if final_pace_target_columns[0] in df_model_ready.columns:
             df_model_ready.dropna(subset=[final_pace_target_columns[0]], inplace=True)


    # 입력 특성(X)의 결측치 처리 (예: 수치형은 평균 또는 중앙값, 범주형은 최빈값 - 여기서는 OHE 후이므로 숫자형만 해당)
    for col in existing_feature_columns: # OHE로 인해 컬럼명 변경될 수 있으므로, OHE 전 컬럼명 기준
        if col in df_model_ready.columns and df_model_ready[col].isnull().any():
            if pd.api.types.is_numeric_dtype(df_model_ready[col]):
                median_val = df_model_ready[col].median()
                df_model_ready[col].fillna(median_val, inplace=True)
                print(f"'{col}' 컬럼의 결측치를 중앙값 ({median_val:.2f})으로 채웠습니다.")
            # else: # 범주형 결측치 (OHE 전이었다면 최빈값 등으로 처리)
                # mode_val = df_model_ready[col].mode()[0]
                # df_model_ready[col].fillna(mode_val, inplace=True)

    print("결측치 처리 완료 (목표변수 NaN 행 일부 제거, 특성 NaN 중앙값 대체).")
    
    # --- 5. 최종 데이터 저장 ---
    try:
        # 저장 경로의 디렉토리 확인 및 생성
        output_dir_path = os.path.dirname(output_csv_path)
        if output_dir_path and not os.path.exists(output_dir_path):
            os.makedirs(output_dir_path)
            print(f"출력 디렉토리 '{output_dir_path}' 생성 완료.")
            
        df_model_ready.to_csv(output_csv_path, index=False, encoding='utf-8-sig')
        print(f"\n모델 학습 준비 완료된 데이터가 '{output_csv_path}'에 저장되었습니다.")
        print("\n최종 데이터 정보 (model_ready_data):")
        df_model_ready.info()
        print("\n최종 데이터 상위 5행 (model_ready_data):")
        print(df_model_ready.head())
        
    except Exception as e:
        print(f"Error: 최종 CSV 파일 저장 중 오류 발생 - {e}")

if __name__ == '__main__':
    # ★★★ 사용자 설정: 입력 파일 경로와 출력 파일 경로를 지정해주세요. ★★★
    # 이 파일은 보스턴, 모스크바, 시카고 데이터가 합쳐지고, 날씨 정보까지 포함된 CSV입니다.
    INPUT_FINAL_CSV_PATH = "./FINAL_marathons_with_weather.csv"  # <<< 경로를 실제 파일로 수정!!
    
    # 모델 학습에 최종적으로 사용될 데이터가 저장될 경로와 파일명
    OUTPUT_MODEL_READY_CSV_PATH = "./model_ready_data.csv" # <<< 저장 경로 수정!!
    # ==============================================================================

    # `os` 모듈 임포트 (파일 경로 다룰 때 필요할 수 있음)
    import os

    prepare_model_ready_data(input_csv_path=INPUT_FINAL_CSV_PATH, 
                             output_csv_path=OUTPUT_MODEL_READY_CSV_PATH)