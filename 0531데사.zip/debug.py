import pandas as pd
import numpy as np
import joblib
import json
import os

# --- 설정값 ---
MODEL_READY_DATA_PATH = "./model_ready_data.csv"
PROBABILITY_MODEL_PATH = "./models/achievement_probability_model.pkl"
IMPUTATION_VALUES_PATH = "./models/imputation_values.json"
# FINAL_MARATHONS_CSV_PATH = "./FINAL_marathons_with_weather.csv" # 필요시 주석 해제 및 경로 수정

# ★★★ prediction_pipeline.py의 것과 반드시 일치시켜야 합니다! ★★★
EXPECTED_MODEL_FEATURES = [
    'age_numeric', 'M/F', 'Year',
    'temperature_race', 'humidity_race',
    'user_weekly_km', 'user_target_time_sec',
    'Dataset_B', 'Dataset_C', 'Dataset_M',
    'Sub_3', 'Sub_4', 'Sub_5', 'Sub_6', 'Sub_7'
]

def analyze_probability_model_training_basis(data_path, imputation_path, model_path):
    print(f"'{data_path}'에서 모델 학습 기반 데이터 로딩 중...")
    try:
        df = pd.read_csv(data_path)
    except FileNotFoundError:
        print(f"FATAL Error: '{data_path}' 파일을 찾을 수 없습니다.")
        return
    print("데이터 로딩 완료.\n")

    # df_for_analysis 초기화 (오류 해결 지점)
    df_for_analysis = df.copy() # 원본 df의 복사본으로 초기화

    # --- 1. 학습 시 사용된 'target_achieved' 정의 재현 및 분석 ---
    print("--- 1. 'target_achieved' 변수 분석 ---")

    if os.path.exists(imputation_path):
        with open(imputation_path, 'r') as f:
            imputation_vals = json.load(f)
        print(f"'{imputation_path}'에서 결측치 대체값 로드.")
        if 'user_target_time_sec' in df_for_analysis.columns and 'user_target_time_sec' in imputation_vals:
            df_for_analysis['user_target_time_sec_imputed'] = df_for_analysis['user_target_time_sec'].fillna(imputation_vals['user_target_time_sec'])
            print(f"'user_target_time_sec'의 NaN을 {imputation_vals['user_target_time_sec']}로 채움.")
        else:
            print("Warning: 'user_target_time_sec'에 대한 대체값이 없거나 컬럼이 없습니다. NaN으로 유지됩니다.")
            df_for_analysis['user_target_time_sec_imputed'] = df_for_analysis.get('user_target_time_sec', pd.Series(index=df_for_analysis.index, dtype=float))
    else:
        print(f"Warning: '{imputation_path}' 파일 없음. 'user_target_time_sec'의 NaN이 그대로 유지될 수 있습니다.")
        df_for_analysis['user_target_time_sec_imputed'] = df_for_analysis.get('user_target_time_sec', pd.Series(index=df_for_analysis.index, dtype=float))

    if 'Final_Time' in df_for_analysis.columns:
        df_valid_for_target = df_for_analysis.dropna(subset=['user_target_time_sec_imputed', 'Final_Time'])
        if not df_valid_for_target.empty:
            # target_achieved 컬럼 생성 또는 업데이트
            df_for_analysis.loc[df_valid_for_target.index, 'target_achieved'] = np.where(
                df_valid_for_target['Final_Time'] <= df_valid_for_target['user_target_time_sec_imputed'], 1, 0
            )
            print("'target_achieved' 컬럼 생성 (Final_Time과 user_target_time_sec_imputed 비교 기반).")
            if df_for_analysis['target_achieved'].isnull().any():
                 print(f"'target_achieved' 생성 후 NaN 값 {df_for_analysis['target_achieved'].isnull().sum()}개 발생.")
        else:
            print("Warning: 'Final_Time' 또는 'user_target_time_sec_imputed'에 유효한 값이 없어, user_target_time_sec 기반 'target_achieved' 생성 불가.")
            if 'target_achieved' not in df_for_analysis.columns: # 컬럼이 아예 없으면 생성
                 df_for_analysis['target_achieved'] = pd.NA


    # Final_Time 기반 target_achieved 생성이 어려웠거나, 컬럼이 여전히 없거나, 모든 값이 NaN인 경우 Sub_X 기반 프록시 사용
    if 'target_achieved' not in df_for_analysis.columns or df_for_analysis['target_achieved'].isnull().all():
        print("Trying to define 'target_achieved' using 'Sub_X' columns as a proxy.")
        if 'Sub_3' in df_for_analysis.columns:
            df_for_analysis['target_achieved'] = df_for_analysis['Sub_3'].astype(int)
            print("임시 'target_achieved': 'Sub_3' 컬럼 사용 (1: Sub3 달성, 0: 그 외).")
        elif 'Sub_4' in df_for_analysis.columns:
            df_for_analysis['target_achieved'] = df_for_analysis['Sub_4'].astype(int)
            print("임시 'target_achieved': 'Sub_4' 컬럼 사용 (1: Sub4 달성, 0: 그 외).")
        else:
            print("Error: 'Final_Time'도 없고 'Sub_X' 컬럼도 없어 'target_achieved'를 정의할 수 없습니다.")
            return

    if 'target_achieved' in df_for_analysis and not df_for_analysis['target_achieved'].isnull().all():
        print("\n'target_achieved' 분포 (학습 데이터 기준):")
        print(df_for_analysis['target_achieved'].value_counts(normalize=True, dropna=False))
    else:
        print("Error: 유효한 'target_achieved'를 확인할 수 없습니다.")
        return

    # (이하 특성 통계치 및 모델 계수 확인 코드는 이전과 동일하게 유지)
    # --- 2. 학습에 사용된 주요 특성 통계치 확인 ---
    print("\n--- 2. 주요 입력 특성 통계치 분석 (결측치 대체 후, 스케일링 전) ---")
    prob_feature_cols_to_analyze = [
        'age_numeric', 'M/F', 'Year', 
        'temperature_race', 'humidity_race',
        'user_weekly_km', 'user_target_time_sec_imputed' 
    ] 
    prob_feature_cols_to_analyze.extend([col for col in df_for_analysis.columns if col.startswith('Dataset_') or col.startswith('Sub_')])
    prob_feature_cols_existing = [col for col in prob_feature_cols_to_analyze if col in df_for_analysis.columns]

    if not prob_feature_cols_existing:
        print("Error: 분석할 주요 특성 컬럼이 데이터에 없습니다.")
    else:
        if 'user_weekly_km' in prob_feature_cols_existing and 'user_weekly_km' in imputation_vals: # imputation_vals 변수명 수정
             df_for_analysis['user_weekly_km'] = df_for_analysis['user_weekly_km'].fillna(imputation_vals['user_weekly_km'])
        
        df_learning_subset = df_for_analysis.dropna(subset=['target_achieved'])
        if not df_learning_subset.empty:
            print(df_learning_subset[prob_feature_cols_existing].describe())
        else:
            print("Warning: 'target_achieved'가 유효한 행이 없어 특성 통계치를 계산할 수 없습니다.")

    # --- 3. 저장된 로지스틱 회귀 모델 계수 확인 ---
    print("\n--- 3. 로지스틱 회귀 모델 계수 확인 ---")
    try:
        prob_model_data_loaded = joblib.load(model_path)
        log_reg_model = prob_model_data_loaded['model']
        # scaler_loaded = prob_model_data_loaded['scaler'] # 스케일러 사용은 예측 시 필요
        
        if hasattr(log_reg_model, 'coef_'):
            # 모델 학습 시 사용된 특성 이름 목록 (EXPECTED_MODEL_FEATURES 사용)
            # EXPECTED_MODEL_FEATURES가 실제 학습 시 순서와 일치해야 함
            if len(log_reg_model.coef_[0]) == len(EXPECTED_MODEL_FEATURES):
                 coefficients = pd.DataFrame(log_reg_model.coef_[0], index=EXPECTED_MODEL_FEATURES, columns=['Coefficient'])
                 print("모델 계수 (스케일링된 특성 기준):")
                 print(coefficients.sort_values(by='Coefficient', ascending=False))
            else:
                print(f"Warning: 모델 계수의 수({len(log_reg_model.coef_[0])})와 EXPECTED_MODEL_FEATURES의 수({len(EXPECTED_MODEL_FEATURES)})가 일치하지 않습니다.")
                print("모델 계수 (인덱스 없이):")
                print(log_reg_model.coef_[0])
        else:
            print("Warning: 로드된 모델에서 계수 정보를 찾을 수 없습니다.")
            
    except FileNotFoundError:
        print(f"Error: 모델 파일 '{model_path}'을 찾을 수 없습니다.")
    except Exception as e:
        print(f"Error: 모델 로딩 또는 계수 확인 중 오류 - {e}")


if __name__ == '__main__':
    analyze_probability_model_training_basis(
        data_path=MODEL_READY_DATA_PATH,
        imputation_path=IMPUTATION_VALUES_PATH,
        model_path=PROBABILITY_MODEL_PATH
    )
    # (이하 점검 단계 1, 3 코드 제안은 이전과 동일하게 유지)
    print("\n--- 점검 단계 1 (예측 파이프라인 입력값 확인) 코드 제안 ---")
    print("""
# prediction_pipeline.py의 predict_marathon_strategy 함수 내부에 다음 print문 추가하여 확인:
# (input_data_aligned 생성 후, 그리고 scaler.transform() 전후)

# ... input_data_aligned = input_data[EXPECTED_MODEL_FEATURES] ...
# print("\\n--- Debug: input_data_aligned (before scaling, dtypes) ---")
# print(input_data_aligned.info())
# print(input_data_aligned.head(1).to_dict(orient='records')) # 실제 값 확인

# ... input_data_scaled = scaler.transform(input_data_aligned) ...
# print("\\n--- Debug: input_data_scaled (after scaling) ---")
# print(input_data_scaled) # 스케일링된 numpy 배열 값 확인
    """)

    print("\n--- 점검 단계 3 (간단한 테스트 케이스로 예측) 코드 제안 ---")
    print("""
# 별도의 테스트 스크립트 또는 Notebook에서 다음을 수행:
# 1. analyze_probability_model_training_basis 결과에서 'target_achieved'가 1인 샘플과 0인 샘플 선정.
# 2. 해당 샘플들의 'age', 'sex_str' (변환 전), 'weekly_km' 등의 원본 입력값을 파악.
# 3. 이 값들을 사용하여 prediction_pipeline.py의 sample_user_inputs 딕셔너리처럼 구성.
# 4. predict_marathon_strategy(**test_case_inputs) 호출하여 확률 값 확인.
#
# 예시 (값은 실제 데이터에서 가져와야 함):
# success_case_inputs = {
#     "age": 30, "sex_str": "남성", "weekly_km": 70.0, 
#     "target_time_total_seconds": 12000, # 예: 3시간 20분
#     "temperature": 10.0, "humidity": 50.0, 
#     "race_year": 2023, "ref_dataset_code": 'B', "aspirational_sub_category": 3
# }
# failure_case_inputs = {
#     "age": 45, "sex_str": "여성", "weekly_km": 30.0,
#     "target_time_total_seconds": 18000, # 예: 5시간
#     "temperature": 25.0, "humidity": 80.0,
#     "race_year": 2024, "ref_dataset_code": 'C', "aspirational_sub_category": 5
# }
# paces_succ, prob_succ, _ = predict_marathon_strategy(**success_case_inputs)
# print(f"성공 케이스 예상 확률: {prob_succ*100:.2f}%")
# paces_fail, prob_fail, _ = predict_marathon_strategy(**failure_case_inputs)
# print(f"실패 케이스 예상 확률: {prob_fail*100:.2f}%")
    """)